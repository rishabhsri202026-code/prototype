import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


def validate_url(value):
    if value:
        parsed = urlparse(value)
        if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("Provider URL must be an HTTP(S) base URL without credentials, query, or fragment.")
        if parsed.scheme == "http" and parsed.hostname not in ("localhost", "127.0.0.1", "::1"):
            raise ValueError("Remote providers require HTTPS. Use loopback HTTP for a local worker.")
    return value.rstrip("/")


@dataclass
class Settings:
    llm_url: str = ""
    llm_model: str = "llama3.2:3b"
    llm_key: str = ""
    vlm_url: str = ""
    vlm_model: str = "Qwen/Qwen2.5-VL-7B-Instruct"
    vlm_key: str = ""
    allow_no_key: bool = False
    sanket_url: str = ""
    password: str = ""
    public_origin: str = ""
    timeout: float = 60

    @classmethod
    def from_env(cls):
        return cls(
            validate_url(os.getenv("LLM_BASE_URL", "")),
            os.getenv("LLM_MODEL", "llama3.2:3b"),
            os.getenv("LLM_API_KEY", ""),
            validate_url(os.getenv("VLM_BASE_URL", "")),
            os.getenv("VLM_MODEL", cls.vlm_model),
            os.getenv("VLM_API_KEY", ""),
            os.getenv("VLM_ALLOW_NO_KEY", "false").lower() == "true",
            validate_url(os.getenv("SANKET_URL", "").strip() or "http://127.0.0.1:8765"),
            os.getenv("APP_PASSWORD", ""),
            os.getenv("PUBLIC_ORIGIN", "").rstrip("/"),
            float(os.getenv("PROVIDER_TIMEOUT", "60")),
        )

    def vision_issue(self):
        if not self.vlm_url:
            return "Set VLM_BASE_URL and VLM_MODEL in the server .env to connect a vision model."
        if not self.vlm_key and not self.allow_no_key:
            return "Set VLM_API_KEY in the server .env. For a private local server only, set VLM_ALLOW_NO_KEY=true."
        return None
