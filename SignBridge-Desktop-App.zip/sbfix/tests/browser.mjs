// Attach to the shared browser. This script never installs or launches a browser.
import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
const endpoint = process.env.CDP_URL;
if (!endpoint) throw new Error('Set CDP_URL to your running browser CDP URL. See docs/TESTING.md.');
const browser = await chromium.connectOverCDP(endpoint);
const page = await browser.contexts()[0].newPage();
const base = process.env.BASE_URL || 'http://localhost:8000';
let assertions = 0;
const check = (condition, message) => { assert.ok(condition, message); assertions += 1; console.log(`PASS ${message}`); };
try {
  await page.addInitScript(() => {
    window.testStreams = [];
    Object.defineProperty(navigator.mediaDevices, 'getUserMedia', { configurable: true, value: async () => {
      if (window.denyCamera) throw new DOMException('Denied', 'NotAllowedError');
      const canvas = document.createElement('canvas'); canvas.width = 640; canvas.height = 480;
      canvas.getContext('2d').fillRect(0, 0, 640, 480);
      const stream = canvas.captureStream(5); window.testStreams.push(stream); return stream;
    } });
  });
  await page.goto(base);
  await page.waitForFunction(() => document.querySelector('#backendStatus').textContent === 'Backend connected');
  check(await page.locator('#modelStatus').textContent() === 'Vision model needs setup', 'frontend connects to actual health endpoint');
  await page.evaluate(() => { window.denyCamera = true; });
  await page.locator('#startCamera').click();
  await page.waitForFunction(() => document.querySelector('#message').textContent.includes('permission was denied'));
  check(await page.locator('#startCamera').isEnabled(), 'camera denial is actionable and recoverable');
  await page.evaluate(() => { window.denyCamera = false; });
  await page.locator('#startCamera').click();
  await page.waitForFunction(() => document.querySelector('#cameraStatus').textContent === 'Camera ready');
  check(await page.locator('#analyze').isDisabled(), 'analysis needs explicit frame-upload consent');
  await page.locator('#consent').check(); await page.locator('#captureMode').selectOption('still');
  await page.locator('#analyze').click();
  await page.waitForFunction(() => document.querySelector('#message').textContent.includes('VLM_BASE_URL'));
  check(await page.locator('#transcriptCount').textContent() === '0', 'unconfigured inference cannot create fake successful history');
  const requests = [];
  let fail = false;
  await page.route('**/api/analyze', async route => {
    const request = route.request().postDataJSON(); requests.push(request);
    if (fail) return route.fulfill({ status: 502, contentType: 'application/json', body: JSON.stringify({ detail: 'Synthetic provider outage for test' }) });
    await route.fulfill({ contentType: 'application/json', body: JSON.stringify({
      observations: [{ kind: 'hand', label: '<img src=x onerror=alert(1)>', meaning: 'Test observation', certainty: 'clear' }],
      sentence: 'An open palm is visible.', suggestions: request.guess_mode ? [{ text: 'Possibly a greeting', reason: 'Test context', certainty: 'uncertain' }] : [],
      source: 'TEST FIXTURE — not model inference', frame_count: request.frames.length, motion_analyzed: request.frames.length > 1,
      interpretation: 'Test only', warnings: ['Synthetic browser fixture']
    }) });
  });
  await page.locator('#analyze').click();
  await page.waitForFunction(() => document.querySelector('#transcriptCount').textContent === '1');
  check(requests[0].frames[0].image.startsWith('data:image/jpeg;base64,'), 'browser sends real canvas JPEG data');
  check(await page.locator('#literal img').count() === 0, 'provider text renders safely without HTML execution');
  check(await page.locator('#suggestionsPanel').isHidden(), 'guess mode off hides predictions');
  await page.locator('#guessMode').check(); await page.locator('#analyze').click();
  await page.getByRole('button', { name: 'Accept suggestion', exact: true }).click();
  check((await page.locator('#transcript').textContent()).includes('accepted a prediction (unverified)'), 'accepted guess is separately recorded as unverified');
  check(!(await page.locator('#natural').textContent()).includes('greeting'), 'accepting a guess never rewrites the observed sentence');
  await page.locator('#analyze').click();
  await page.getByRole('button', { name: 'Reject', exact: true }).click();
  check((await page.locator('#transcript').textContent()).includes('rejected a prediction'), 'rejecting a prediction is supported');
  await page.locator('#captureMode').selectOption('sequence');
  const beforeCancel = requests.length;
  await page.locator('#analyze').click();
  check(await page.locator('#analyze').isDisabled(), 'analysis button prevents overlapping capture');
  await page.locator('#stopCamera').click();
  await page.waitForTimeout(500);
  check(requests.length === beforeCancel, 'stop during temporal capture cancels upload');
  check(await page.evaluate(() => window.testStreams.every(stream => stream.getTracks().every(track => track.readyState === 'ended'))), 'stop releases synthetic browser camera tracks');
  await page.locator('#startCamera').click();
  await page.waitForFunction(() => document.querySelector('#cameraStatus').textContent === 'Camera ready');
  await page.locator('#analyze').click();
  await page.waitForFunction(() => document.querySelector('#message').textContent.includes('8 frame(s)'));
  const frames = requests.at(-1).frames;
  check(frames.length === 8 && frames[7].timestamp_ms - frames[0].timestamp_ms >= 2700, 'motion analysis sends eight genuinely time-separated captures');
  fail = true;
  await page.locator('#liveMode').check();
  await page.waitForFunction(() => document.querySelector('#message').textContent.includes('Synthetic provider outage'));
  check(!(await page.locator('#liveMode').isChecked()), 'provider error stops live analysis');
  await page.locator('#clearTranscript').click();
  check(await page.locator('#transcriptCount').textContent() === '0' && await page.locator('#suggestionsPanel').isHidden(), 'clear removes transcript and suggestion state');
  await page.locator('#language').selectOption('isl');
  check(await page.locator('#captureMode').isDisabled() && await page.locator('#guessMode').isDisabled(), 'ISL enforces temporal capture and does not offer ungrounded guesses');
  await page.locator('#language').selectOption('wsl');
  check(await page.locator('#analyze').isDisabled(), 'unconfigured WSL cannot be analyzed');
  await page.setViewportSize({ width: 390, height: 844 });
  check(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'mobile viewport has no horizontal overflow');
  await page.locator('#stopCamera').click();
  console.log(`${assertions} browser checks passed. Synthetic media and provider fixtures; no actual model or physical camera validation.`);
} finally { await page.close(); await browser.close(); }
