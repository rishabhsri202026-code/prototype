# Get a shareable HTTPS link

The website and backend are one deployment. A GPU/model provider is separate. An HTTPS frontend cannot call a laptop's loopback endpoint or an HTTP remote provider.

## Recommended beginner route: Render web service + remote vision endpoint

1. Put the **contents of this project folder** into a new GitHub repository or a separate branch. Do not upload `.env`, `.venv`, `sanket-upstream`, checkpoints, caches, or node_modules. If keeping this within `copilot-hack`, configure `signbridge-connect` as the hosting service root directory.
2. In https://dashboard.render.com/, create a **New Web Service**, connect your repository/branch, and choose the **Docker** runtime. Use the supplied Dockerfile. The app listens on port 8000; set the health check path to `/api/health`. Alternatively use the supplied `render.yaml` blueprint when this folder is the repository root.
3. Set private environment variables in the dashboard: `VLM_BASE_URL`, `VLM_MODEL`, `VLM_API_KEY`, and a long unique `APP_PASSWORD`. Do not add them to frontend files. The blueprint generates an app password; obtain it from your private environment settings and share it only with intended users.
4. Set `PUBLIC_ORIGIN` to your assigned URL, such as `https://signbridge-connect-abc.onrender.com`, without a trailing slash. Redeploy after setting it. Keep `VLM_ALLOW_NO_KEY=false` for token-authenticated remote providers.
5. Open that HTTPS URL, enter the app password, and click **Check connection**. A listed model is not proof of multimodal inference; run one actual camera analysis and confirm the configured endpoint supports eight `image_url` inputs.
6. Open the same link on a phone, start the camera, then try both front/rear preferences. Send the URL through WhatsApp. If its embedded browser blocks camera permission, open the URL in the system browser.

The free web tier, if currently offered in your region/account, may sleep and has resource limits; check current provider terms. It does not include GPU inference. GPU hosting and model API calls can incur charges. Live mode makes repeated requests; start with on-demand use and provider budget limits.

`APP_PASSWORD` is optional for local development and strongly recommended for shared paid inference. It is sent over HTTPS and kept in browser memory only. This is a small private-group deployment, not a multi-tenant service: public-scale use needs proper account authentication, per-user budgets, a reverse-proxy request rate limit, and a distributed inference queue. Current resource limits are per process. Run exactly one Uvicorn worker.

## Other Docker hosts

```sh
docker build -t signbridge-connect .
docker run --rm -p 8000:8000 --env-file .env signbridge-connect
```

Use the host's managed HTTPS proxy/custom domain. On a VPS, put an HTTPS reverse proxy in front of port 8000 and restrict direct public access to the port. Do not expose Sanket's worker publicly. Keep API keys on the server. The image contains only the web/API, not the large models.

For Sanket on the same machine, run it on loopback and keep the main backend on that machine so it can use `http://127.0.0.1:8765`. In a container, loopback refers to that container; use a deliberate private TLS networking setup instead of assuming host loopback is reachable. Do not make the unprotected worker a public web service.

## Production readiness checklist

- `/api/health` returns backend ready and reports model configuration honestly.
- Correct password permits inference; incorrect password gets 401.
- The configured model really processes image input and responds with the expected schema.
- One real static gesture and one real temporal gesture were evaluated on target devices.
- Verify any third-party model/dataset license before redistribution or commercial hosting.
- Review provider frame retention and configure usage/spending limits.

This project has **not been deployed to a permanent public host** in this task: no hosting account or deployment credentials were supplied. The development Preview is available for inspection; it is not a promise of permanent hosting. Once you provide your chosen hosting service, deployment can continue from these files.
