import pytest
from fastapi.testclient import TestClient
from backend.config import Settings
from backend.main import create_app
from tests.test_backend import payload


def test_hybrid_analysis_route():
    with TestClient(create_app(Settings())) as client:
        response = client.post("/api/analyze", json=payload(4, language="hybrid"))
        assert response.status_code == 200
        data = response.json()
        assert "Hybrid" in data["source"]
        assert len(data["observations"]) > 0
        assert data["motion_analyzed"] is True


def test_comparative_benchmark_route():
    with TestClient(create_app(Settings())) as client:
        # Test GET benchmark
        res_get = client.get("/api/benchmark")
        assert res_get.status_code == 200
        report = res_get.json()
        assert report["status"] == "completed"
        assert len(report["comparisons"]) == 3
        arch_names = [c["architecture"] for c in report["comparisons"]]
        assert any("Landmark" in a for a in arch_names)
        assert any("RGB" in a for a in arch_names)
        assert any("Hybrid" in a for a in arch_names)

        # Test POST benchmark with frames
        res_post = client.post("/api/benchmark", json=payload(8))
        assert res_post.status_code == 200
        assert "ISL Minimal Pair" in res_post.json()["minimal_pair_tested"]


def _hand(open_):
    lm = [[0.5, 0.8, 0.0] for _ in range(21)]
    for mcp, x, pip, tip in ((5, .45, 6, 8), (9, .5, 10, 12), (13, .55, 14, 16), (17, .6, 18, 20)):
        lm[mcp] = [x, .62, 0.0]
        lm[pip] = [x, .52 if open_ else .66, 0.0]
        lm[tip] = [x, .40 if open_ else .70, 0.0]
    lm[2], lm[3] = [.42, .72, 0.0], [.38, .66, 0.0]
    lm[4] = [.30, .60, 0.0] if open_ else [.44, .64, 0.0]
    return lm


def test_hybrid_reports_only_measured_evidence():
    with TestClient(create_app(Settings())) as client:
        body = payload(4, language="hybrid")
        for frame in body["frames"]:
            frame["landmarks"] = _hand(False)
        data = client.post("/api/analyze", json=body).json()
        assert data["observations"][0]["label"] == "Closed fist"
        assert "namaste" not in str(data).lower()
        body = payload(4, language="hybrid")
        data = client.post("/api/analyze", json=body).json()
        assert data["observations"][0]["certainty"] == "unknown" and data["sentence"] is None
