"""Complete-label prefix decoding: permitted subword tokens depend on the prefix."""
class LabelDecoder:
    def __init__(self, tokenizer, labels):
        self.tokenizer = tokenizer
        self.trie = {}
        self.max_tokens = 1
        for label in sorted(labels):
            ids = tokenizer.encode(label, add_special_tokens=False) + [tokenizer.eos_token_id]
            self.max_tokens = max(self.max_tokens, len(ids))
            branch = self.trie
            for token in ids:
                branch = branch.setdefault(token, {})

    def allowed(self, batch_id, input_ids):
        branch = self.trie
        # T5 starts decoder input with its pad token.
        for token in input_ids.tolist()[1:]:
            if token not in branch: return [self.tokenizer.eos_token_id]
            branch = branch[token]
        return list(branch) or [self.tokenizer.eos_token_id]

    def decode(self, model, video, pose):
        hidden = model(video, pose)
        # Match upstream training/inference: T5 encoder processes fused embeddings.
        # Passing inputs_embeds invokes that encoder (do not bypass it).
        ids = model.text_decoder.generate(inputs_embeds=hidden,
            prefix_allowed_tokens_fn=self.allowed, max_new_tokens=self.max_tokens,
            num_beams=4, early_stopping=True)
        return self.tokenizer.decode(ids[0], skip_special_tokens=True).strip()
