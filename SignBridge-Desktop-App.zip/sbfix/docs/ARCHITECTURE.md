# Architecture and source inspection

## Existing project inspected

The connected IDE repository was `rishabhsri202026-code/copilot-hack`, not `signbridge7`. This application is an additive folder in that checkout, on `coderabbit/signbridge-ai-translator/c37a89e7`. No remote repository was modified or pushed.

Inspected `signbridge7` at `228b7b390e5726296b2cecd373481a38acb82899`. It contains a static camera/MediaRecorder UI, service worker, Windows scripts, and a standard-library HTTP bridge. Its Sanket source, checkpoint, caches, and virtual environment are absent. Original UI and integration files are preserved under `legacy/` as reference; those scripts are not part of the new launch path. Do not run the legacy setup to install the new app.

Inspected upstream `ayush2635/Sanket-ISL-Translator` at `da2f6374ffc8b395dc6cd014edefe6720546050b`. The source includes `architecture.py`, `extract_features.py`, `setup_cache.py`, and `INCLUDE_Labels.csv`. Its architecture uses TimeSformer RGB features, a 195-dimensional upper-pose/hand temporal encoder, gated fusion, and T5 decoding. Pose order is 23 upper-body points, then left hand, then right hand. RGB preprocessing is resize to 224×224 and tensor conversion without normalization. The worker retains those preprocessing conventions.

The original bridge assigns its global model before loading succeeds, so later health checks can mistake a failed checkpoint for a loaded model. The new worker publishes the model only after strict checkpoint loading succeeds. `torch.load(..., weights_only=True)` is required; unsafe pickle loading is not used as a fallback. Upstream Gemini grammar expansion is deliberately not invoked because it can add unsupported words and an additional undisclosed provider.

The upstream word decoder constrains *token IDs*, not complete INCLUDE labels; novel combinations are still possible. The new adapter rejects output outside the complete label vocabulary. It does not manufacture exact gloss alignment, calibrated confidence, or phrase accuracy. One capture is one isolated sign hypothesis. Recovering continuous phrase segmentation requires a validated dataset and evaluation beyond these eight sparse frames.

## Data path

```mermaid
flowchart LR
  Camera[Browser camera] --> Capture[1 JPEG or 8 ordered JPEGs]
  Capture --> API[FastAPI: validation / authentication / limits]
  API -->|General mode| VLM[Configurable vision-language endpoint]
  API -->|ISL mode| Worker[Private Sanket sequence worker]
  VLM --> Guard[Schema and evidence guards]
  Worker --> Guard
  Guard --> Literal[Literal observations]
  Guard --> Sentence[Supported generated wording]
  Guard --> Guesses[Separate optional predictions]
```

Browser preview is local. The user explicitly opts into sending frames. At most eight JPEGs at 640px longest edge are sampled over about 2.8 seconds. The backend decodes/validates dimensions, bounds strings and arrays, and enforces a 3.7MB total body limit. Camera images/context are not logged. Transcripts are kept only in browser memory, limited to 100 entries; the last five observed entries may be included as model context. Accepted guesses never become observed context.

One inference runs at a time per server process, with two seconds minimum between starts. Live mode waits until a result finishes, then waits 5–30 seconds; it stops after 20 results, any error, consent withdrawal, or the page becoming hidden. Keep one Uvicorn worker; horizontal replicas need a shared rate limiter and account quotas before broad public usage.

## Model choice

| Candidate | Role and tradeoff |
|---|---|
| Qwen2.5-VL-7B-Instruct | Baseline general visual model: Apache 2.0, documented image/video support, mature OpenAI-compatible vLLM serving. Receives actual images through `image_url` data URLs. Here we use ordered images with timestamps, not native video-token input. General hand/expression/motion descriptions remain unvalidated. |
| Smaller Qwen VL variants | Lower memory and possibly lower cost, but fine hand shapes can become less reliable. Check each model's license and multi-image support; do not assume all variants share terms. |
| Larger/newer open-weight VLMs | Replace `VLM_MODEL` and the server endpoint after evaluating structured JSON, eight-image support, and gesture accuracy. More parameters do not establish sign-language competence. |
| Sanket RGB + pose + T5 | Specialized trained ISL path using INCLUDE vocabulary. Requires compatible checkpoint and full encoder/decoder/tokenizer assets. No confidence calibration or verified sentence translation provided. |

Source: [Qwen model card](https://huggingface.co/Qwen/Qwen2.5-VL-7B-Instruct), inspected during implementation. We chose a documented baseline rather than claiming an untested newer model is better. The VLM describes visible smiling/not smiling/uncertain appearance; it does not infer emotion. General vision descriptions are not sign-language translations. Future WSL/other-language support needs an identified standard, licensed training/evaluation dataset, compatible sequence recognizer, and measured abstention thresholds.

Seven billion bf16 parameters alone use approximately 14GB before vision activations/KV cache. Budget a 24GB-class CUDA GPU for a small multi-image deployment, reduce resolution/context, and benchmark actual capacity; this is not a measured guarantee. Quantization may lower memory with accuracy tradeoffs. CPU-only VLM hosting is generally unsuitable for live use. A managed multi-image inference endpoint avoids local GPU requirements, with provider usage charges. No free quota is promised. Web hosting and GPU/model inference costs are separate.
