@echo off
setlocal
cd /d "%~dp0"
echo SignBridge Connect - local launcher
if exist ".sanket-venv\Scripts\python.exe" if exist "sanket-upstream\Sanket - ISL Translator\weights\model_best.pth" (call START-SIGNBRIDGE-WITH-ISL.bat & exit /b)
if not exist ".venv\Scripts\python.exe" (
  py -3.11 -m venv .venv
  if errorlevel 1 goto python_error
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto install_error
if not exist .env copy .env.example .env >nul
".venv\Scripts\python.exe" scripts\launch.py
pause
exit /b
:python_error
echo Install Python 3.11 64-bit from python.org, including the Windows py launcher, then try again.
pause
exit /b 1
:install_error
echo Package installation failed. Check your internet connection and the error above.
pause
exit /b 1
