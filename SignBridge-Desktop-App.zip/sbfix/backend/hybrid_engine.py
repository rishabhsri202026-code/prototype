"""Hybrid recognition for SignBridge Connect, based only on evidence actually received.

Uses the 21 MediaPipe hand landmarks the browser detected for each captured frame and reports
measurable facts: which fingers are extended, which generic pose that matches, and how the hand
moved across the sequence. It never invents words or signs. It is NOT a validated sign-language
translator, and it says so in every result.
"""
import math
from collections import Counter
from typing import List, Optional
from .schemas import AnalysisRequest, AnalysisResult, Observation, Suggestion

WRIST, THUMB_TIP, THUMB_IP, THUMB_MCP, INDEX_MCP, MIDDLE_MCP = 0, 4, 3, 2, 5, 9
FINGERS = {"index": (8, 6, 5), "middle": (12, 10, 9), "ring": (16, 14, 13), "pinky": (20, 18, 17)}


def _d(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def finger_state(lm: List[List[float]]) -> dict:
    """Same geometric heuristics as the browser overlay: a finger is extended when its tip is clearly farther from the wrist than its joints."""
    wrist = lm[WRIST]
    up = {name: _d(lm[tip], wrist) > _d(lm[pip], wrist) * 1.08 and _d(lm[tip], wrist) > _d(lm[mcp], wrist) * 1.2
          for name, (tip, pip, mcp) in FINGERS.items()}
    thumb_out = _d(lm[THUMB_TIP], lm[INDEX_MCP]) > _d(lm[THUMB_MCP], lm[INDEX_MCP]) * 1.2
    thumb_up = thumb_out and lm[THUMB_TIP][1] < lm[THUMB_IP][1] - 0.035 and lm[THUMB_TIP][1] < lm[THUMB_MCP][1]
    thumb_down = thumb_out and lm[THUMB_TIP][1] > lm[THUMB_IP][1] + 0.035 and lm[THUMB_TIP][1] > lm[THUMB_MCP][1]
    return {**up, "thumb": thumb_out, "thumb_up": thumb_up, "thumb_down": thumb_down, "count": sum(up.values())}


def pose_label(f: dict) -> str:
    if f["thumb_up"] and f["count"] <= 1: return "Thumbs up"
    if f["thumb_down"] and f["count"] <= 1: return "Thumbs down"
    if f["index"] and f["middle"] and not f["ring"] and not f["pinky"]: return "Peace sign (two fingers)"
    if f["index"] and not f["middle"] and not f["ring"] and not f["pinky"]: return "Pointing (one finger)"
    if f["count"] >= 3 and f["thumb"]: return "Open palm"
    if f["count"] == 0 and not f["thumb"]: return "Closed fist"
    return "Hand visible (pose not in the generic set)"


def finger_summary(f: dict) -> str:
    names = [n for n in ("thumb", "index", "middle", "ring", "pinky") if f[n]]
    return (", ".join(names) + " extended") if names else "no fingers extended"


def movement(points: List[List[float]], scales: List[float]) -> Optional[tuple]:
    """Wrist travel across the sequence, in units of palm size, plus the main direction in the camera image."""
    if len(points) < 2:
        return None
    scale = max(0.04, sum(scales) / len(scales))
    path = sum(_d(a, b) for a, b in zip(points, points[1:])) / scale
    dx, dy = (points[-1][0] - points[0][0]) / scale, (points[-1][1] - points[0][1]) / scale
    direction = ""
    if math.hypot(dx, dy) > 0.5:
        direction = ("right" if dx > 0 else "left") if abs(dx) >= abs(dy) else ("down" if dy > 0 else "up")
    return path, direction


async def analyze_hybrid(request: AnalysisRequest, settings=None, client=None) -> AnalysisResult:
    frames = request.frames
    n = len(frames)
    with_hand = [fr for fr in frames if fr.landmarks]
    warnings = [
        "Reports measured hand-landmark geometry only; it does not translate sign language and invents no words.",
        "Generic pose labels are heuristics, not verified ISL signs.",
    ]
    base = dict(source="SignBridge Hybrid Landmark Analyzer", frame_count=n, motion_analyzed=n > 1, warnings=warnings)

    if not with_hand:
        return AnalysisResult(
            observations=[Observation(kind="hand", label="No hand landmarks received",
                                      meaning="No hand was tracked during capture. Check the hand-tracking model has loaded and keep one hand fully in view.",
                                      certainty="unknown")],
            sentence=None, suggestions=[],
            interpretation="No landmark evidence, so the analyzer abstains", **base)

    states = [finger_state(fr.landmarks) for fr in with_hand]
    labels = [pose_label(s) for s in states]
    top, votes = Counter(labels).most_common(1)[0]
    share = votes / len(labels)
    best = states[labels.index(top)]

    observations = [Observation(
        kind="hand", label=top,
        meaning=f"{finger_summary(best)}; same pose in {votes} of {len(labels)} frames with a tracked hand ({len(with_hand)} of {n} captured)",
        certainty="clear" if share >= 0.75 and len(with_hand) >= max(1, n // 2) else "uncertain")]
    if len(set(labels)) > 1:
        observations.append(Observation(kind="hand", label="Pose changed during capture",
                                        meaning="Sequence: " + " → ".join(dict.fromkeys(labels)), certainty="uncertain"))

    sentence = f"{top} detected." if observations[0].certainty == "clear" and not top.startswith("Hand visible") else None

    if len(with_hand) >= 2:
        pts = [fr.landmarks[WRIST] for fr in with_hand]
        scales = [_d(fr.landmarks[WRIST], fr.landmarks[MIDDLE_MCP]) for fr in with_hand]
        path, direction = movement(pts, scales)
        if path > 1.0:
            observations.append(Observation(
                kind="movement", label="Hand moved" + (f" mostly {direction} in the camera image" if direction else ""),
                meaning=f"Wrist travelled about {path:.1f} palm-widths across the sequence", certainty="clear"))
        else:
            observations.append(Observation(kind="movement", label="Hand mostly still",
                                            meaning=f"Wrist travelled about {path:.1f} palm-widths across the sequence", certainty="clear"))

    suggestions: List[Suggestion] = []
    if request.guess_mode:
        suggestions.append(Suggestion(
            text="No sign-language meaning can be suggested",
            reason="No trained ISL model is installed, so a meaning would be a guess. Add a validated model or use the Vision model mode for a description of the frame.",
            certainty="unknown"))

    return AnalysisResult(observations=observations, sentence=sentence, suggestions=suggestions,
                          interpretation="Measured from hand landmarks; no sign vocabulary applied", **base)
