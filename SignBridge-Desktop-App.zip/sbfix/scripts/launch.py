"""Start the local server and open SignBridge in an app-style browser window."""
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def free_port(start=8000):
    # Avoid accidentally opening an older/stale SignBridge instance.
    for port in range(start, start + 50):
        with socket.socket() as probe:
            probe.settimeout(0.3)
            if probe.connect_ex(("127.0.0.1", port)) == 0:
                continue
        with socket.socket() as probe:
            try:
                probe.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise SystemExit("No free port found between 8000 and 8049.")

def open_app_window(url):
    """Prefer a borderless app window; fall back to the default browser."""
    candidates = []
    for command in ("chrome", "msedge"):
        found = shutil.which(command)
        if found:
            candidates.append(found)
    local = os.environ.get("LOCALAPPDATA", "")
    program_files = os.environ.get("PROGRAMFILES", r"C:\Program Files")
    program_files_x86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
    candidates.extend([
        str(Path(local) / "Google/Chrome/Application/chrome.exe") if local else "",
        str(Path(program_files) / "Google/Chrome/Application/chrome.exe"),
        str(Path(program_files_x86) / "Google/Chrome/Application/chrome.exe"),
        str(Path(local) / "Microsoft/Edge/Application/msedge.exe") if local else "",
        str(Path(program_files) / "Microsoft/Edge/Application/msedge.exe"),
        str(Path(program_files_x86) / "Microsoft/Edge/Application/msedge.exe"),
    ])
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            subprocess.Popen([candidate, f"--app={url}"], close_fds=True)
            return "app window"
    webbrowser.open(url)
    return "browser tab"

PORT = free_port()
URL = f"http://localhost:{PORT}"
process = subprocess.Popen([sys.executable, "-m", "uvicorn", "backend.main:app", "--host", "127.0.0.1", "--port", str(PORT)], cwd=ROOT)
try:
    for _ in range(120):
        if process.poll() is not None:
            raise SystemExit("The server could not start. Read the error above.")
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/api/health", timeout=1) as response:
                if response.status == 200:
                    time.sleep(0.3)
                    if process.poll() is not None:
                        raise SystemExit("The server stopped right after starting. Read the terminal error.")
                    window = open_app_window(URL)
                    print(f"SignBridge is ready at {URL} in a {window}.")
                    print("Keep this terminal open while using SignBridge. Close the app window, then press Ctrl+C here to stop the local server.")
                    break
        except OSError:
            time.sleep(0.25)
    else:
        raise SystemExit("The backend did not become ready. Check terminal diagnostics.")
    process.wait()
except KeyboardInterrupt:
    pass
finally:
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
