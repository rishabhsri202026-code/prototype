import pytest
from fastapi.testclient import TestClient
from backend.config import Settings
from backend.main import create_app
from backend.sentences import compose
from backend.decoding import LabelDecoder

@pytest.mark.parametrize('signs,sentence,additions', [
    (['I','happy'], 'I am happy.', ['am']),
    (['she','Doctor'], 'She is a doctor.', ['is','a']),
    (['he','Artist'], 'He is an artist.', ['is','an']),
    (['we','cold'], 'We are cold.', ['are']),
    (['I','need','water'], 'I need water.', []),
])
def test_grammar_preserves_content(signs,sentence,additions):
    result=compose(signs)
    assert result['sentence']==sentence
    assert result['grammar_additions']==additions
    assert 'not a verified translation' in result['provenance']

@pytest.mark.parametrize('signs',[[],['water'],['need','water'],['I','water'],['doctor','medicine'],['I','happy','doctor'],['not','happy']])
def test_ambiguous_sequences_abstain(signs):
    assert compose(signs)['sentence'] is None


def test_sentence_api_validation_and_authentication():
    with TestClient(create_app(Settings(password='fixture'))) as client:
        assert client.post('/api/sentence',json={'signs':['I','happy']}).status_code==401
        headers={'authorization':'Bearer fixture'}
        response=client.post('/api/sentence',json={'signs':['I','happy']},headers=headers)
        assert response.json()['sentence']=='I am happy.'
        for words in [['x']*17,['<script>'],['x'*61]]:
            assert client.post('/api/sentence',json={'signs':words},headers=headers).status_code==422


class Tokens:
    eos_token_id=1
    def encode(self,label,add_special_tokens=False):
        return {'happy':[2,3], 'hospital':[2,4], 'I':[5]}[label]

class Prefix:
    def __init__(self,tokens):self.tokens=tokens
    def tolist(self):return self.tokens


def test_word_prefix_constraints_disallow_arbitrary_token_combinations():
    decoder=LabelDecoder(Tokens(),['happy','hospital','I'])
    assert set(decoder.allowed(0,Prefix([0])))=={2,5}
    assert set(decoder.allowed(0,Prefix([0,2])))=={3,4}
    assert decoder.allowed(0,Prefix([0,2,3]))==[1]
    assert decoder.allowed(0,Prefix([0,5]))==[1]
    assert decoder.max_tokens==3
