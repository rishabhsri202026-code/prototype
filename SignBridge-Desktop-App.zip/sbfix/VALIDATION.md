# Validation report — 12 October 2026

## Passed

- **27 backend tests**: image/schema validation, actual multimodal request construction, missing endpoint/token, provider errors/timeouts, guess-mode enforcement, uncertainty, unsupported motion/sign claims, authentication, origin and body limits, concurrency, and model status.
- **5 camera unit tests**: track cleanup, late permission resolution after stop, playback failure, facing constraints and permission guidance.
- **19 shared Chromium browser checks**: actual frontend/backend health, camera denial recovery, consent, frame payloads, two-column output, safe text rendering, prediction accept/reject, no guess insertion, cancellation, ordered temporal capture, live-error stop, clear history, language gates and mobile overflow.
- **Accessibility scan**: initial low-contrast violations fixed; final automated scan had zero violations. Manual review remained for decorative symbols and silent preview video. This is not a full WCAG certification.
- **Python imports/compile and dependency checks** passed for the web application and optional worker environments.
- **Docker build and runtime smoke check** passed after fixing copied-file ownership. Container runs as UID 1000 and serves a healthy backend.
- **Actual Sanket checkpoint loading**: downloaded the public `model_best.pth` at Hugging Face revision `e62628f263f014833dd9a00bddf8c07b42a18ebb` (1,438,145,048 bytes). Safe loading found 541 tensors; strict architecture matching succeeded against upstream revision `da2f6374ffc8b395dc6cd014edefe6720546050b`, with 259 INCLUDE labels.
- **Actual Sanket numerical inference**: `scripts/check_sanket.py` executed trained RGB/pose forward computation and T5 decoding on synthetic input; embeddings were finite. No synthetic output is shown as a recognized sign.
- **Main API → real Sanket worker**: eight blank frames produced an HTTP 200 unknown result. The worker also processed repeated hand-only test images and abstained. These are preprocessing/abstention checks, not sign-recognition evaluations.
- **Asset setup reuse**: `scripts/setup_sanket.py --download-checkpoint` correctly preserved the existing pinned source, caches, and checkpoint.

Browser tests use generated canvas streams and clearly identified provider response fixtures. There is no production fixture/fallback path. HTTP provider tests validate the request/response contract, not the visual model's quality.

## Not verified / still required

- **General vision model inference**: no VLM endpoint or API token was supplied. Missing configuration produces a 503 with specific instructions. The installed emulator catalog has no compatible visual inference service; no emulator output is passed off as real recognition.
- **ISL accuracy or fluent translation**: no labeled real signing clip or the user's local checkpoint was supplied. The public checkpoint's numerical execution is verified; its sign accuracy, generalization, confidence calibration, and continuous phrase translation are not.
- **Physical camera, real microphone-free device behavior, Safari/mobile hardware**: the sandbox's tests use synthetic media. Test the intended devices before relying on it.
- **Windows launcher execution**: Windows commands provided and launcher code inspected/compiled where applicable; no Windows machine available.
- **Permanent public HTTPS deployment**: deployment files supplied; no hosting account configured. Development Preview is running.
- **WSL**: intended language standard and dataset remain unconfirmed. It stays unavailable.

## Environment

Amazon Linux. Web tests: Python 3.9.25, FastAPI 0.115.12, Pydantic 2.11.7, httpx 0.28.1. Optional model worker: Python 3.11.17, torch 2.8.0+cpu, torchvision 0.23.0+cpu, transformers 4.51.3, MediaPipe 0.10.21. Camera tests: Node 24.14.1. Browser tests: Playwright 1.56.1 attached to shared Chromium. Docker: 25.0.16; Python 3.11 image.

See `docs/TESTING.md` for reproducible commands. Do not interpret a passed software test as a verified language translation.
