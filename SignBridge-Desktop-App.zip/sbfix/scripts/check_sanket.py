"""Optional real checkpoint numerical smoke test; does NOT measure sign accuracy."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from backend.sanket_worker import engine

engine.load()
if engine.model is None:
    raise SystemExit(engine.error)
torch = engine.torch
torch.set_num_threads(2)
# Synthetic inputs verify tensor shapes, finite outputs, and actual decoder execution.
video = torch.zeros((1, 8, 3, 224, 224), device=engine.device)
pose = torch.full((1, 8, 195), 0.5, device=engine.device)
with torch.inference_mode():
    hidden = engine.model(video, pose)
    if not torch.isfinite(hidden).all():
        raise SystemExit("Non-finite embeddings: numerical inference failed.")
    text = engine.model.generate_translation(video_frames=video, pose_data=pose, tokenizer=engine.tokenizer, max_length=15)
    if not isinstance(text, str):
        raise SystemExit("Decoder returned the wrong type.")
print("PASS: strict checkpoint load, finite RGB/pose embeddings, and T5 decoding executed.")
print("Synthetic input only. No recognition accuracy or translation claim. Output intentionally not presented as a sign.")
