import test from 'node:test';
import assert from 'node:assert/strict';
import { CameraController, cameraError } from '../frontend/camera.js';
function fixture(getUserMedia) { return new CameraController({ srcObject: null, play: async () => {} }, { getUserMedia }); }
test('stop releases every camera track and clears preview', async () => {
  let stopped = 0;
  const camera = fixture(async () => ({ getTracks: () => [{ stop: () => stopped++ }, { stop: () => stopped++ }] }));
  await camera.start('user'); camera.stop();
  assert.equal(stopped, 2); assert.equal(camera.video.srcObject, null); assert.equal(camera.stream, null);
});
test('late permission resolution cannot reopen stopped camera', async () => {
  let resolve, stopped = 0;
  const camera = fixture(() => new Promise(done => { resolve = done; }));
  const pending = camera.start('user'); camera.stop();
  resolve({ getTracks: () => [{ stop: () => stopped++ }] });
  assert.equal(await pending, false); assert.equal(stopped, 1); assert.equal(camera.stream, null);
});
test('playback failure releases acquired tracks', async () => {
  let stopped = false;
  const camera = fixture(async () => ({ getTracks: () => [{ stop: () => { stopped = true; } }] }));
  camera.video.play = async () => { throw new Error('playback failed'); };
  await assert.rejects(camera.start('environment'), /playback failed/); assert.ok(stopped);
});
test('facing request uses an ideal constraint and never requests audio', async () => {
  let options;
  const camera = fixture(async value => { options = value; return { getTracks: () => [] }; });
  await camera.start('environment'); assert.equal(options.video.facingMode.ideal, 'environment'); assert.equal(options.audio, false);
});
test('permission errors provide an actionable message', () => {
  assert.match(cameraError({ name: 'NotAllowedError' }), /Site settings/);
});
