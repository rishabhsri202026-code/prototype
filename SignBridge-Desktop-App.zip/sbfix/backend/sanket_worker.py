"""Optional isolated Sanket worker. Bind ONLY to loopback; see docs/MODELS.md."""
import base64
import csv
import io
import logging
import os
import sys
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from .schemas import AnalysisRequest, AnalysisResult, Observation
from .main import BodyLimit

logger = logging.getLogger("sanket")


class SanketEngine:
    def __init__(self, root):
        self.root = Path(root).resolve() if root else None
        self.model = None
        self.tokenizer = None
        self.error = "Model not loaded."
        self.lock = threading.Lock()

    def load(self):
        # Publish state only after ALL initialization succeeds.
        self.model = None
        root = self.root
        required = ["architecture.py", "extract_features.py", "INCLUDE_Labels.csv", "weights/model_best.pth",
                    "cache/t5-base/config.json", "cache/timesformer/config.json"]
        missing = required if root is None else [name for name in required if not (root / name).is_file()]
        if missing:
            self.error = "Missing Sanket assets: " + ", ".join(missing)
            return
        try:
            import torch
            import mediapipe as mp
            import numpy as np
            import torchvision.transforms as transforms
            from transformers import AutoTokenizer
            sys.path.insert(0, str(root))
            from architecture import DualStreamGMTFormer
            from extract_features import extract_keypoints
            # Require trusted upstream source and offline caches.
            tokenizer = AutoTokenizer.from_pretrained(str(root / "cache/t5-base"), local_files_only=True)
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            model = DualStreamGMTFormer(t5_model_name="t5-base")
            checkpoint = torch.load(str(root / "weights/model_best.pth"), map_location="cpu", weights_only=True)
            state = checkpoint.get("model_state_dict", checkpoint)
            model.load_state_dict(state, strict=True)
            model.to(device).eval()
            with open(root / "INCLUDE_Labels.csv", newline="", encoding="utf-8-sig") as handle:
                labels = {row["Label"].strip().casefold() for row in csv.DictReader(handle)}
            if not labels:
                raise ValueError("Empty INCLUDE label vocabulary.")
            self.torch, self.np, self.mp = torch, np, mp
            self.transform = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor()])
            self.keypoints, self.device, self.labels = extract_keypoints, device, labels
            self.tokenizer, self.model = tokenizer, model
            self.error = ""
        except Exception as exc:
            self.error = "Sanket initialization failed; inspect worker logs, dependency versions, checkpoint, and complete caches."
            logger.exception("Sanket initialization failed (%s)", type(exc).__name__)
            self.model = None

    def analyze(self, payload):
        from PIL import Image
        if self.model is None:
            raise HTTPException(503, self.error)
        if payload.language != "isl" or len(payload.frames) != 8:
            raise HTTPException(422, "Sanket accepts eight-frame ISL sequences only.")
        if not self.lock.acquire(blocking=False):
            raise HTTPException(429, "Sanket worker is busy.")
        try:
            frames, poses = [], []
            hands_visible = 0
            # Fresh tracker prevents one person's state leaking into another clip.
            with self.mp.solutions.holistic.Holistic(static_image_mode=False, model_complexity=1) as tracker:
                for frame in payload.frames:
                    with Image.open(io.BytesIO(base64.b64decode(frame.image.split(",", 1)[1]))) as image:
                        rgb = image.convert("RGB")
                        landmarks = tracker.process(self.np.asarray(rgb))
                        hands_visible += bool(landmarks.left_hand_landmarks or landmarks.right_hand_landmarks)
                        frames.append(self.transform(rgb))
                        poses.append(self.keypoints(landmarks))
            observations = []
            if hands_visible >= 4:
                video = self.torch.stack(frames).unsqueeze(0).to(self.device)
                pose = self.torch.tensor(self.np.array(poses), dtype=self.torch.float32).unsqueeze(0).to(self.device)
                with self.torch.inference_mode():
                    prediction = self.model.generate_translation(video_frames=video, pose_data=pose, tokenizer=self.tokenizer, max_length=15).strip()
                # Token constraints are NOT word-level constraints. Reject novel strings.
                if prediction.casefold() in self.labels:
                    observations.append(Observation(kind="sign", label=prediction, meaning="ISL decoder hypothesis (INCLUDE vocabulary)", certainty="uncertain"))
            return AnalysisResult(observations=observations, sentence=None, suggestions=[], source="Sanket DualStreamGMTFormer + T5",
                frame_count=8, motion_analyzed=True, interpretation="Unverified isolated-sign hypothesis",
                warnings=["No calibrated confidence or exact gloss alignment is exposed by this checkpoint.",
                          "Capture one isolated sign per sequence. Continuous phrase translation is not validated.",
                          "Unknown is returned when hands are insufficiently visible or decoding falls outside the label vocabulary."])
        except HTTPException:
            raise
        except Exception as exc:
            logger.error("Sanket inference failed (%s)", type(exc).__name__)
            raise HTTPException(500, "Sanket inference failed. Check worker dependencies and model compatibility.") from exc
        finally:
            self.lock.release()


# Prefer explicit configuration; otherwise discover the bundled upstream layout.
_default_root = Path(__file__).resolve().parent.parent / "sanket-upstream" / "Sanket - ISL Translator"
_configured_root = os.getenv("SANKET_ROOT", "").strip()
engine = SanketEngine(_configured_root or (str(_default_root) if _default_root.is_dir() else ""))


@asynccontextmanager
async def lifespan(app):
    engine.load()
    yield


app = FastAPI(title="Private Sanket worker", lifespan=lifespan)
app.add_middleware(BodyLimit)


@app.get("/health")
def health():
    return {"model_loaded": engine.model is not None, "detail": engine.error or "Checkpoint loaded; accuracy unvalidated."}


@app.post("/analyze", response_model=AnalysisResult)
def analyze(payload: AnalysisRequest):
    return engine.analyze(payload)
