export class CameraController {
  constructor(video, mediaDevices = navigator.mediaDevices) {
    this.video = video;
    this.mediaDevices = mediaDevices;
    this.stream = null;
    this.generation = 0;
  }

  async start(facing = 'user') {
    this.stop();
    const generation = this.generation;
    if (!this.mediaDevices?.getUserMedia) {
      throw new Error('This browser does not expose camera access. Open SignBridge at http://localhost:8000 in Chrome or Edge, not as a file.');
    }

    // Try a simple camera request first if the preferred resolution/facing mode is unsupported.
    // Do not retry permission/security failures; those need user action.
    const requests = [
      { video: { facingMode: { ideal: facing }, width: { ideal: 960 }, height: { ideal: 720 } }, audio: false },
      { video: { facingMode: { ideal: facing } }, audio: false },
      { video: true, audio: false }
    ];
    let acquired = null;
    let lastError = null;
    for (let i = 0; i < requests.length; i++) {
      try {
        acquired = await this.mediaDevices.getUserMedia(requests[i]);
        break;
      } catch (error) {
        lastError = error;
        if (['NotAllowedError', 'PermissionDeniedError', 'SecurityError', 'NotReadableError'].includes(error?.name)) throw error;
        if (!['OverconstrainedError', 'ConstraintNotSatisfiedError', 'NotFoundError', 'TypeError'].includes(error?.name)) throw error;
      }
    }
    if (!acquired) throw lastError || new Error('Could not open any available camera.');

    if (generation !== this.generation) {
      acquired.getTracks().forEach(track => track.stop());
      return false;
    }

    this.stream = acquired;
    this.video.muted = true;
    this.video.autoplay = true;
    this.video.playsInline = true;
    this.video.srcObject = acquired;

    try {
      // Wait for real video dimensions; getUserMedia resolving does not guarantee frames are ready.
      if ((!this.video.videoWidth || !this.video.videoHeight) && this.video.addEventListener) {
        await new Promise((resolve, reject) => {
          let settled = false;
          const finish = (fn, value) => {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            this.video.removeEventListener('loadedmetadata', onReady);
            this.video.removeEventListener('error', onError);
            fn(value);
          };
          const onReady = () => finish(resolve);
          const onError = () => finish(reject, new Error('Camera opened but the browser could not read its video stream.'));
          const timer = setTimeout(() => finish(reject, new Error('Camera permission was granted, but no video frames arrived. Close other camera apps and retry.')), 8000);
          this.video.addEventListener('loadedmetadata', onReady, { once: true });
          this.video.addEventListener('error', onError, { once: true });
          if (this.video.videoWidth && this.video.videoHeight) onReady();
        });
      }
      await this.video.play();
      // Test doubles may not expose dimensions; browsers must have a decoded frame.
      if (generation !== this.generation) {
        acquired.getTracks().forEach(track => track.stop());
        return false;
      }
      if (this.video.addEventListener && (!this.video.videoWidth || !this.video.videoHeight)) {
        throw new Error('Camera stream started but has no video dimensions. Try the other camera or close other camera apps.');
      }
      return true;
    } catch (error) {
      acquired.getTracks().forEach(track => track.stop());
      if (this.stream === acquired) this.stream = null;
      if (this.video.srcObject === acquired) this.video.srcObject = null;
      throw error;
    }
  }

  stop() {
    this.generation += 1;
    this.stream?.getTracks().forEach(track => track.stop());
    this.stream = null;
    if (this.video) {
      this.video.pause?.();
      this.video.srcObject = null;
    }
  }

  frame(timestamp) {
    if (!this.stream || !this.video.videoWidth || this.video.readyState < 2) {
      throw new Error('Camera is not ready yet. Wait for the live preview, then try again.');
    }
    const canvas = document.createElement('canvas');
    const scale = Math.min(640 / this.video.videoWidth, 640 / this.video.videoHeight, 1);
    canvas.width = Math.max(1, Math.round(this.video.videoWidth * scale));
    canvas.height = Math.max(1, Math.round(this.video.videoHeight * scale));
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Could not create a frame capture canvas.');
    context.drawImage(this.video, 0, 0, canvas.width, canvas.height);
    return { image: canvas.toDataURL('image/jpeg', 0.75), timestamp_ms: Math.round(timestamp) };
  }
}

export function cameraError(error) {
  const messages = {
    NotAllowedError: 'Camera permission is blocked. In Chrome, click the icon left of the address bar → Site settings → Camera → Allow, then reload.',
    PermissionDeniedError: 'Camera permission was denied. Allow camera access in Chrome Site settings, then reload.',
    NotFoundError: 'No camera was found. Connect a webcam or choose a phone camera.',
    NotReadableError: 'The camera is already in use or Windows cannot open it. Close Camera, Teams, Zoom, and other browser tabs using the camera, then retry.',
    OverconstrainedError: 'The requested camera settings are unsupported. Choose the other camera and retry.',
    SecurityError: 'Camera access is blocked. Open the app through http://localhost:8000 or HTTPS, not by opening index.html directly.'
  };
  return messages[error?.name] || error?.message || 'Camera could not start. Reload the page and try again.';
}
