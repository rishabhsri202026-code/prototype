import { CameraController, cameraError } from './camera.js';
// MediaPipe is loaded lazily in initLandmarker() so a CDN failure cannot stop the camera or UI from working.
let FilesetResolver, HandLandmarker, DrawingUtils;

const $ = id => document.getElementById(id);
const cameraVideo = $('camera');
const overlayCanvas = $('overlay');
const ctx = overlayCanvas.getContext('2d');
const camera = new CameraController(cameraVideo);

let busy = false, starting = false, epoch = 0, controller = null, liveTimer = null, healthTimer = null;
let accessPassword = '', currentResult = null, history = [], context = [], liveCount = 0;
let landmarker = null, rafId = 0, lastVideoTime = -1, lastLandmarks = null;
let customSamples = [], customSigns = loadCustomSigns();
let islGlossBuffer = [], sentenceRequestId = 0;

const status = (message, error = false) => {
  $('message').textContent = message;
  $('message').className = `message${error ? ' error' : ''}`;
};
const node = (tag, text, className) => {
  const el = document.createElement(tag);
  if (text) el.textContent = text;
  if (className) el.className = className;
  return el;
};

function controls() {
  const ready = !!camera.stream;
  $('startCamera').disabled = ready || starting;
  $('stopCamera').disabled = !ready && !starting;
  $('analyze').disabled = !ready || !$('consent').checked || $('language').value === 'wsl';
  $('facing').disabled = starting;
  $('language').disabled = busy;
  $('captureMode').disabled = busy || $('language').value === 'isl';
  $('guessMode').disabled = busy || $('language').value === 'isl';
  $('cameraStatus').textContent = ready ? 'Camera ready' : starting ? 'Requesting camera' : 'Camera off';
  $('cameraDot').className = ready ? 'ready' : '';
  $('previewLabel').textContent = ready ? 'DUAL-STREAM CAMERA LIVE · PREVIEW' : 'CAMERA IS OFF';
  $('cameraPlaceholder').hidden = ready;
  $('captureBadge').textContent = busy ? 'PROCESSING' : 'PREVIEW';
  $('analyzeLabel').textContent = busy ? 'Translating…' : $('liveMode').checked ? 'Stop live translation' : 'Start live translation';
  $('analyze').setAttribute('aria-pressed', String($('liveMode').checked));
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(accessPassword ? { Authorization: `Bearer ${accessPassword}` } : {}),
      ...options.headers
    }
  });
  const data = await response.json().catch(() => { throw new Error('The backend returned an unreadable response.'); });
  if (!response.ok) {
    if (response.status === 401 && !$('authDialog').open) $('authDialog').showModal();
    throw new Error(typeof data.detail === 'string' ? data.detail : 'Request rejected. Check backend configuration.');
  }
  return data;
}

function modelStatus(data) {
  const selected = $('language').value === 'general' ? data.vision : $('language').value === 'hybrid' ? data.hybrid : data[$('language').value];
  const labels = {
    unconfigured: 'Vision model needs setup',
    configured_unverified: 'Model configured · unverified',
    unavailable: 'Selected model unavailable',
    reachable: 'Vision endpoint reachable',
    loaded: 'Sanket checkpoint loaded',
    ready: 'Hybrid Multi-modal Engine Active',
    error: 'Model connection error',
    unverified: 'Model availability unverified'
  };
  $('modelStatus').textContent = labels[selected?.state] || 'Model status ready';
  $('modelDot').className = ['reachable', 'loaded', 'ready'].includes(selected?.state) ? 'ready' : 'warn';
  $('modelStatus').title = selected?.detail || '';
}

async function health(initial = false) {
  try {
    const data = await api('/api/health', { signal: AbortSignal.timeout(8000) });
    $('backendStatus').textContent = 'Backend connected';
    $('backendDot').className = 'ready';
    modelStatus(data);
    if (initial) status('SignBridge Hybrid Recognition Engine initialized. Camera is local until you analyze.');
    if (data.authentication_required && !accessPassword && !$('authDialog').open) $('authDialog').showModal();
  } catch {
    $('backendStatus').textContent = 'Backend unavailable';
    $('backendDot').className = 'warn';
    if (initial) status('Cannot reach the backend. Ensure server is running on http://localhost:8000.', true);
  }
}

// Landmark Detection & Canvas Rendering
async function initLandmarker() {
  if (landmarker) return landmarker;
  try {
    if (!HandLandmarker) ({ FilesetResolver, HandLandmarker, DrawingUtils } = await import('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.21/vision_bundle.mjs'));
    const vision = await FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.21/wasm');
    const options = {
      runningMode: 'VIDEO',
      numHands: 2,
      minHandDetectionConfidence: 0.5,
      minHandPresenceConfidence: 0.5,
      minTrackingConfidence: 0.5
    };
    const modelAssetPath = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
    try {
      landmarker = await HandLandmarker.createFromOptions(vision, { ...options, baseOptions: { modelAssetPath, delegate: 'GPU' } });
    } catch {
      landmarker = await HandLandmarker.createFromOptions(vision, { ...options, baseOptions: { modelAssetPath, delegate: 'CPU' } });
    }
  } catch (err) {
    console.warn('MediaPipe HandLandmarker init deferred or offline:', err);
  }
  return landmarker;
}

function resizeOverlay() {
  const r = cameraVideo.getBoundingClientRect();
  if (!r.width || !r.height) return;
  const dpr = window.devicePixelRatio || 1;
  overlayCanvas.width = Math.round(r.width * dpr);
  overlayCanvas.height = Math.round(r.height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function drawLandmarks(results) {
  resizeOverlay();
  const w = overlayCanvas.clientWidth, h = overlayCanvas.clientHeight;
  ctx.clearRect(0, 0, w, h);
  if (!results || !results.landmarks || !results.landmarks.length) {
    $('landmarkBadge').hidden = true;
    return;
  }
  $('landmarkBadge').hidden = false;
  if (!$('showSkeleton').checked) return;

  const draw = new DrawingUtils(ctx);
  ctx.save();
  ctx.shadowColor = 'rgba(0, 210, 255, 0.8)';
  ctx.shadowBlur = 10;
  for (const hand of results.landmarks) {
    draw.drawConnectors(hand, HandLandmarker.HAND_CONNECTIONS, { color: '#00d2ff', lineWidth: 3.5 });
    draw.drawLandmarks(hand, { color: '#ffffff', fillColor: '#ff7300', lineWidth: 1.5, radius: 4 });
  }
  ctx.restore();
}

// Hand landmarks currently tracked in the browser, sent with each captured frame (21 x [x, y, z]).
function compactLandmarks() {
  if (!lastLandmarks || lastLandmarks.length !== 21) return undefined;
  return lastLandmarks.map(p => [Number(p.x.toFixed(4)), Number(p.y.toFixed(4)), Number((p.z || 0).toFixed(4))]);
}

// Immediate, on-device generic pose feedback. This is geometry-based, NOT ISL translation.
let lastLocalPose = '';
let localPoseStableFrames = 0;
function localPoseFromLandmarks(points) {
  if (!points || points.length !== 21) return null;
  const extended = (tip, pip) => points[tip].y < points[pip].y - 0.025;
  const index = extended(8, 6), middle = extended(12, 10);
  const ring = extended(16, 14), pinky = extended(20, 18);
  const thumb = Math.abs(points[4].x - points[2].x) > 0.07;
  const count = [index, middle, ring, pinky].filter(Boolean).length;
  if (index && middle && !ring && !pinky) return 'Peace sign (two fingers)';
  if (index && !middle && !ring && !pinky) return 'Pointing (one finger)';
  if (count >= 3 && thumb) return 'Open palm';
  if (count === 0 && !thumb) return 'Closed fist';
  if (thumb && count === 0) return points[4].y < points[3].y ? 'Thumbs up' : 'Thumb gesture';
  return 'Hand visible (pose not in the generic set)';
}
function updateInstantLocalFeedback() {
  if (!$('liveMode') || !$('liveMode').checked || $('language').value !== 'hybrid') return;
  if (!lastLandmarks || lastLandmarks.length !== 21) {
    $('processingStatus').textContent = 'Live · waiting for a tracked hand…';
    return;
  }
  const pose = localPoseFromLandmarks(lastLandmarks);
  if (!pose) return;
  if (pose === lastLocalPose) localPoseStableFrames += 1;
  else { lastLocalPose = pose; localPoseStableFrames = 1; }
  // Avoid flicker: two consecutive local camera updates, typically a few tens of ms.
  if (localPoseStableFrames < 2) return;
  $('literal').className = 'result-content';
  const row = node('div', '', 'observation');
  row.append(node('strong', pose), node('small', 'hand pose · on-device geometric estimate · not an ISL meaning'));
  $('literal').replaceChildren(row);
  $('certainty').textContent = 'GENERIC POSE';
  $('natural').className = 'result-content';
  $('natural').replaceChildren(node('p', `${pose} detected.`, 'subtitle'));
  $('speak').disabled = !('speechSynthesis' in window);
  $('processingStatus').textContent = 'Live · local pose feedback updates as your hand changes. Full AI interpretation runs separately.';
}

function trackingLoop() {
  if (!camera.stream) return;
  if (landmarker && cameraVideo.readyState >= 2 && cameraVideo.currentTime !== lastVideoTime) {
    lastVideoTime = cameraVideo.currentTime;
    try {
      const results = landmarker.detectForVideo(cameraVideo, performance.now());
      drawLandmarks(results);
      if (results.landmarks && results.landmarks.length > 0) {
        lastLandmarks = results.landmarks[0];
        $('captureCustom').disabled = false;
      } else {
        lastLandmarks = null;
        $('captureCustom').disabled = true;
      }
    } catch (e) {
      // frame pass
    }
  }
  updateInstantLocalFeedback();
  rafId = requestAnimationFrame(trackingLoop);
}

async function start() {
  if (starting) return;
  starting = true; controls(); status('Waiting for camera permission…');
  const mine = epoch;
  try {
    const ready = await camera.start($('facing').value);
    if (!ready || mine !== epoch) return;
    cameraVideo.classList.toggle('mirrored', $('facing').value === 'user');
    overlayCanvas.classList.toggle('mirrored', $('facing').value === 'user');
    camera.stream.getTracks().forEach(track => track.addEventListener('ended', () => {
      stop(); status('The camera disconnected. Reconnect it and start again.', true);
    }));
    status('Camera preview is live. Initializing local hand tracking…');
    initLandmarker().then((model) => {
      if (!camera.stream) return;
      if (model) {
        status('Camera and hand tracking are ready.');
        trackingLoop();
      } else {
        status('Camera is ON, but hand tracking could not load. Check internet/CDN access; camera preview should remain visible.', true);
      }
    }).catch((trackingError) => {
      console.error('Hand tracking initialization failed:', trackingError);
      if (camera.stream) status('Camera is ON, but hand tracking failed to initialize. Check internet/CDN access.', true);
    });
  } catch (error) {
    if (mine === epoch) status(cameraError(error), true);
  } finally {
    starting = false; controls();
  }
}

function cancelAnalysis() {
  epoch += 1;
  controller?.abort(); controller = null;
  clearTimeout(liveTimer); liveTimer = null;
  busy = false;
  $('processingStatus').textContent = 'Capture stopped. No new frames will be sent.';
}

function stop() {
  cancelAnalysis();
  cancelAnimationFrame(rafId);
  ctx.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);
  $('landmarkBadge').hidden = true;
  $('liveMode').checked = false;
  camera.stop(); starting = false;
  window.speechSynthesis?.cancel();
  controls();
}

function delay(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal.aborted) return reject(new DOMException('Aborted', 'AbortError'));
    const abort = () => { clearTimeout(timer); reject(new DOMException('Aborted', 'AbortError')); };
    const timer = setTimeout(() => { signal.removeEventListener('abort', abort); resolve(); }, ms);
    signal.addEventListener('abort', abort, { once: true });
  });
}

async function analyze() {
  if (busy || !camera.stream || !$('consent').checked) return;
  clearTimeout(liveTimer);
  busy = true; controls();
  const mine = epoch;
  const localController = new AbortController(); controller = localController;
  const deadline = setTimeout(() => localController.abort(), 95000);
  const language = $('language').value;
  const sequence = language === 'isl' || $('captureMode').value === 'sequence';
  const frameCount = language === 'isl' ? 8 : sequence ? 8 : 2;
  // Sanket requires eight temporal samples, but they do not need 180 ms gaps.
  // Keep timestamps safely above the backend's 80 ms minimum span, including 2-frame requests.
  const frameDelay = frameCount === 2 ? 100 : 100;

  try {
    const frames = [], started = performance.now();
    status(language === 'isl' ? 'Capturing 8 fast-sampled frames for Sanket ISL inference…' : sequence ? 'Capturing 8 fast-sampled frames for temporal analysis…' : 'Capturing 2 frames for fast visual interpretation…');
    for (let i = 0; i < frameCount; i += 1) {
      if (i) await delay(frameDelay, localController.signal);
      if (mine !== epoch) return;
      frames.push({ ...camera.frame(performance.now() - started), landmarks: compactLandmarks() });
      $('processingStatus').textContent = `Capturing frame ${i + 1} of ${frameCount}…`;
    }
    $('processingStatus').textContent = language === 'isl' ? 'Frames sent · waiting for the configured Sanket ISL worker…' : 'Frames sent · evaluating the selected recognition pipeline…';
    const result = await api('/api/analyze', {
      method: 'POST',
      signal: localController.signal,
      body: JSON.stringify({ frames, language, guess_mode: $('guessMode').checked, context })
    });
    if (mine !== epoch) return;
    render(result);
    status(`Analysis complete · ${result.frame_count} frame(s) · ${result.motion_analyzed ? 'temporal multimodal fusion' : 'static observations only'}.`);
    $('processingStatus').textContent = 'Analysis complete. Uncertainty preserved.';
    if ($('liveMode').checked) liveCount += 1;
  } catch (error) {
    if (mine === epoch) {
      $('liveMode').checked = false;
      status(error.name === 'AbortError' ? 'Analysis timed out. Live analysis paused; check model availability and try again.' : `Analysis stopped: ${error.message}. Live analysis paused so the same error is not repeated.`, true);
      $('processingStatus').textContent = 'Previous results unchanged.';
    }
  } finally {
    clearTimeout(deadline);
    if (mine === epoch) {
      busy = false; controller = null; controls();
      if ($('liveMode').checked && camera.stream && $('consent').checked) {
        liveTimer = setTimeout(analyze, Number($('frequency').value) * 1000);
      }
    }
  }
}

async function realizeIslSentence(signs) {
  const requestId = ++sentenceRequestId;
  if (!signs.length) return;
  $('processingStatus').textContent = `ISL glosses: ${signs.join(' · ')} · forming sentence…`;
  try {
    const draft = await api('/api/sentence', {
      method: 'POST',
      body: JSON.stringify({ signs })
    });
    if (requestId !== sentenceRequestId || $('language').value !== 'isl') return;
    if (draft.sentence) {
      $('natural').replaceChildren(node('p', draft.sentence, 'subtitle'));
      $('speak').disabled = !('speechSynthesis' in window);
      $('processingStatus').textContent = 'English sentence draft updated from recognized ISL glosses. Verify meaning against the signs.';
      if (currentResult) currentResult.sentence = draft.sentence;
    }
  } catch (error) {
    if (requestId === sentenceRequestId) {
      $('processingStatus').textContent = `ISL glosses detected; sentence layer unavailable: ${error.message}`;
    }
  }
}

function render(result) {
  currentResult = result;
  $('literal').replaceChildren();
  $('literal').className = 'result-content';
  for (const observation of result.observations) {
    const row = node('div', '', 'observation');
    row.append(node('strong', observation.label), node('small', `${observation.kind} · ${observation.certainty} · ${observation.meaning}`));
    $('literal').append(row);
  }
  if (!result.observations.length) {
    $('literal').append(node('p', 'Unknown — ambiguous visual or kinematic evidence.', 'subtitle'));
  }
  $('certainty').textContent = !result.observations.length ? 'UNKNOWN' : result.observations.every(o => o.certainty === 'clear') ? 'MODEL: CLEAR' : 'UNCERTAIN';

  $('natural').className = 'result-content';
  $('natural').replaceChildren(node('p', result.sentence || (result.source?.includes('Sanket')
    ? 'ISL gloss detected. Building a sentence as more signs arrive…'
    : 'Uncertainty preserved: Insufficient evidence for full sentence.'), 'subtitle'));
  $('speak').disabled = !result.sentence || !('speechSynthesis' in window);
  $('resultTime').textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if ($('language').value === 'isl') {
    const glosses = (result.observations || []).filter(o => o.kind === 'sign' && o.label)
      .map(o => o.label.trim());
    if (glosses.length) {
      let appended = false;
      for (const gloss of glosses) {
        const normalized = gloss.trim().toLowerCase();
        if (!islGlossBuffer.length || islGlossBuffer[islGlossBuffer.length - 1].toLowerCase() !== normalized) {
          islGlossBuffer.push(gloss.trim());
          appended = true;
        }
      }
      islGlossBuffer = islGlossBuffer.slice(-8);
      // Don't call the sentence LLM on every polling cycle while the signer holds
      // the same pose. Only re-realize when a genuinely new gloss arrives.
      if (appended) realizeIslSentence(islGlossBuffer.slice());
    }
  }
  $('resultWarnings').textContent = `${result.source} · ${result.interpretation}. ${result.warnings.join(' ')}`;

  const literal = result.observations.map(o => `${o.label} (${o.certainty})`).join(', ') || 'Unknown';
  context.push(literal.slice(0, 300));
  context = context.slice(-5);
  history.push({ time: new Date(), text: `Observed: ${literal}. Target: ${result.sentence || 'Preserved uncertainty.'}` });
  history = history.slice(-100);
  renderHistory();
  renderSuggestions();
}

function renderSuggestions() {
  $('suggestions').replaceChildren();
  const suggestions = $('guessMode').checked ? currentResult?.suggestions || [] : [];
  $('suggestionsPanel').hidden = suggestions.length === 0;
  suggestions.forEach(suggestion => {
    const box = node('div', '', 'suggestion');
    box.append(node('strong', `${suggestion.text} · ${suggestion.certainty}`), node('p', suggestion.reason));
    for (const accepted of [true, false]) {
      const button = node('button', accepted ? 'Accept suggestion' : 'Reject', `button ${accepted ? 'primary' : 'secondary'}`);
      button.addEventListener('click', () => {
        box.replaceChildren(node('p', `${accepted ? 'Accepted' : 'Rejected'} prediction: ${suggestion.text}. Still unverified.`));
        history.push({ time: new Date(), text: `User ${accepted ? 'accepted' : 'rejected'} prediction: ${suggestion.text}` });
        history = history.slice(-100); renderHistory();
        currentResult.suggestions = currentResult.suggestions.filter(item => item !== suggestion);
      });
      box.append(button);
    }
    $('suggestions').append(box);
  });
}

function renderHistory() {
  $('transcript').replaceChildren();
  $('transcriptCount').textContent = history.length;
  if (!history.length) {
    $('transcript').append(node('li', 'Start with a gesture. Your session will appear here.', 'transcript-empty'));
  }
  for (const item of history) {
    const row = node('li', '');
    row.append(node('time', item.time.toLocaleTimeString()), node('span', item.text));
    $('transcript').append(row);
  }
}

// Comparative Benchmark Execution
async function runComparativeBenchmark() {
  const btn = $('runBenchmarkBtn');
  btn.disabled = true;
  btn.textContent = 'Evaluating Streams…';
  $('benchmarkSampleInfo').textContent = 'Running 3-way ablation test: Landmark-Only vs RGB-Only vs Hybrid Gated Fusion…';

  try {
    let payload = null;
    if (camera.stream && cameraVideo.readyState >= 2) {
      const frames = [];
      const started = performance.now();
      for (let i = 0; i < 8; i++) {
        frames.push(camera.frame(i * 350));
      }
      payload = { frames, language: 'hybrid' };
    }
    const report = await api('/api/benchmark', {
      method: payload ? 'POST' : 'GET',
      ...(payload ? { body: JSON.stringify(payload) } : {})
    });

    $('benchmarkSampleInfo').textContent = `${report.test_condition} · ${report.minimal_pair_tested}`;
    const [landmark, rgb, hybrid] = report.comparisons;

    // Landmark-Only
    $('bmLandmarkLatency').textContent = `${landmark.latency_ms} ms`;
    $('bmLandmarkConf').textContent = `${Math.round(landmark.confidence * 100)}%`;
    $('bmLandmarkOcc').textContent = landmark.occlusion_handling;
    $('bmLandmarkContact').textContent = landmark.contact_detection;
    $('bmLandmarkVerdict').textContent = landmark.verdict;

    // RGB-Only
    $('bmRgbLatency').textContent = `${rgb.latency_ms} ms`;
    $('bmRgbConf').textContent = `${Math.round(rgb.confidence * 100)}%`;
    $('bmRgbOcc').textContent = rgb.occlusion_handling;
    $('bmRgbContact').textContent = rgb.contact_detection;
    $('bmRgbVerdict').textContent = rgb.verdict;

    // Hybrid
    $('bmHybridLatency').textContent = `${hybrid.latency_ms} ms`;
    $('bmHybridConf').textContent = `${Math.round(hybrid.confidence * 100)}%`;
    $('bmHybridOcc').textContent = hybrid.occlusion_handling;
    $('bmHybridContact').textContent = hybrid.contact_detection;
    $('bmHybridVerdict').textContent = hybrid.verdict;

    $('benchmarkTakeaway').innerHTML = `<strong>Validation Takeaway:</strong> ${report.takeaway}<br><small style="margin-top:6px;display:block;">${report.uncertainty_guarantee}</small>`;
    status('Comparative benchmark complete. Results verified in Validation Lab.');
  } catch (err) {
    status(`Benchmark failed: ${err.message}`, true);
  } finally {
    btn.disabled = false;
    btn.textContent = '⚡ Run Comparative Benchmark';
  }
}

// Personal Dictionary Helpers
function loadCustomSigns() {
  try { return JSON.parse(localStorage.getItem('signbridge.customSigns') || '[]'); } catch { return []; }
}
function persistCustomSigns() {
  try { localStorage.setItem('signbridge.customSigns', JSON.stringify(customSigns)); } catch {}
}
function normalizeLandmarks(lm) {
  const wrist = lm[0], scale = Math.max(0.04, Math.hypot(lm[9].x - wrist.x, lm[9].y - wrist.y));
  return lm.flatMap(p => [(p.x - wrist.x) / scale, (p.y - wrist.y) / scale, (p.z - (wrist.z || 0)) / scale]);
}
function renderCustomSigns() {
  const host = $('customSigns');
  host.replaceChildren();
  if (!customSigns.length) {
    host.append(node('p', 'No custom signs saved yet.', 'empty-small'));
    return;
  }
  for (const sign of customSigns) {
    const row = node('div', '', 'custom-sign-row');
    const glyph = node('span', '✳', 'custom-sign-glyph');
    const copy = node('div', '', 'custom-sign-copy');
    copy.append(node('strong', sign.name), node('small', `${sign.templates?.length || 0} samples · saved on device`));
    const remove = node('button', '×', 'remove-sign');
    remove.addEventListener('click', () => {
      customSigns = customSigns.filter(s => s.id !== sign.id);
      persistCustomSigns(); renderCustomSigns();
    });
    row.append(glyph, copy, remove);
    host.append(row);
  }
}

function languageForStatus() { return $('language').value; }

// Event Listeners
$('startCamera').addEventListener('click', start);
$('stopCamera').addEventListener('click', () => { stop(); status('Camera stopped. Tracks released.'); });
$('facing').addEventListener('change', async () => { if (camera.stream) { stop(); await start(); } });
$('analyze').addEventListener('click', () => {
  if ($('liveMode').checked) {
    $('liveMode').checked = false;
    clearTimeout(liveTimer);
    if (controller) controller.abort();
    status('Live translation stopped. Your last translation remains visible.');
    $('processingStatus').textContent = 'Live translation is paused.';
    controls();
    return;
  }
  if (!camera.stream || !$('consent').checked) {
    status('Start the camera and keep consent enabled before translating.', true);
    return;
  }
  $('liveMode').checked = true;
  liveCount = 0;
  controls();
  status(languageForStatus() === 'isl' ? 'Live ISL translation started. Sampling signs continuously; sentence updates when new glosses are recognized.' : 'Live translation started. Local pose feedback is immediate; model interpretation updates as inference completes.');
  analyze();
});
$('captureMode').addEventListener('change', controls);
$('guessMode').addEventListener('change', renderSuggestions);
$('runBenchmarkBtn')?.addEventListener('click', runComparativeBenchmark);

$('consent').addEventListener('change', () => {
  if (!$('consent').checked) { cancelAnalysis(); $('liveMode').checked = false; }
  controls();
});

$('liveMode').addEventListener('change', () => {
  clearTimeout(liveTimer); liveCount = 0;
  if ($('liveMode').checked) {
    if (!camera.stream || !$('consent').checked) {
      $('liveMode').checked = false;
      status('Start camera and check consent before enabling live mode.', true);
      return;
    }
    analyze();
  }
});

$('language').addEventListener('change', () => {
  clearTimeout(liveTimer); $('liveMode').checked = false; context = []; islGlossBuffer = []; sentenceRequestId += 1;
  if (currentResult) currentResult.suggestions = [];
  renderSuggestions();
  const val = $('language').value;
  lastLocalPose = ''; localPoseStableFrames = 0;
  $('languageHint').textContent = val === 'hybrid'
    ? 'Fuses spatial visual context with kinematic joint coordinates to resolve contact and minimal pairs.'
    : val === 'isl'
    ? 'Isolated ISL sign hypothesis from trained Sanket worker.'
    : val === 'wsl'
    ? 'WSL dataset and standard not configured.'
    : 'Visible hand poses and expressions via Vision-Language Model.';
  controls(); health();
});

$('checkConnection').addEventListener('click', async () => {
  $('checkConnection').disabled = true;
  try {
    const result = await api('/api/models/check', { method: 'POST', signal: AbortSignal.timeout(15000) });
    modelStatus(result);
    status(`Hybrid: ${result.hybrid?.detail || 'Ready'} | Vision: ${result.vision?.detail} | ISL: ${result.isl?.detail}`);
  } catch (error) {
    status(error.message, true);
  } finally {
    $('checkConnection').disabled = false;
  }
});

$('speak').addEventListener('click', () => {
  if (currentResult?.sentence) {
    speechSynthesis.cancel();
    speechSynthesis.speak(new SpeechSynthesisUtterance(currentResult.sentence));
  }
});

$('clearTranscript').addEventListener('click', () => {
  cancelAnalysis(); $('liveMode').checked = false; history = []; context = []; currentResult = null;
  window.speechSynthesis?.cancel(); renderHistory(); renderSuggestions();
  $('literal').className = 'result-content'; $('literal').replaceChildren(node('p', 'Session cleared.', 'subtitle'));
  $('natural').className = 'result-content'; $('natural').replaceChildren(node('p', 'Ready for a new conversation.', 'subtitle'));
  $('resultWarnings').textContent = ''; $('certainty').textContent = 'NO RESULT'; $('resultTime').textContent = 'Waiting for your next moment';
  $('speak').disabled = true; controls();
});

// Custom Sign Recorder Listeners
$('captureCustom')?.addEventListener('click', () => {
  if (!lastLandmarks) {
    $('customStatus').textContent = 'No hand detected. Keep hand steady in camera view.';
    return;
  }
  if (customSamples.length >= 3) customSamples = [];
  customSamples.push(normalizeLandmarks(lastLandmarks));
  $('sampleMeterFill').style.width = `${(customSamples.length / 3) * 100}%`;
  $('customStatus').textContent = `Captured sample ${customSamples.length} of 3. Shift angle slightly and capture again.`;
  $('saveCustom').disabled = customSamples.length < 3;
});

$('saveCustom')?.addEventListener('click', () => {
  const name = $('customSignName').value.trim();
  if (!name || customSamples.length < 3) return;
  customSigns.unshift({ id: Date.now().toString(36), name, templates: [...customSamples] });
  customSamples = [];
  $('sampleMeterFill').style.width = '0%';
  $('saveCustom').disabled = true;
  $('customSignName').value = '';
  persistCustomSigns(); renderCustomSigns();
  $('customStatus').textContent = `"${name}" saved to personal dictionary.`;
});

$('clearCustom')?.addEventListener('click', () => {
  customSigns = []; customSamples = [];
  persistCustomSigns(); renderCustomSigns();
  $('sampleMeterFill').style.width = '0%';
  $('saveCustom').disabled = true;
  $('customStatus').textContent = 'All custom signs removed.';
});

function info(title, paragraphs) {
  $('dialogTitle').textContent = title;
  $('dialogContent').replaceChildren(...paragraphs.map(t => node('p', t)));
  $('infoDialog').showModal();
}

$('privacyButton').addEventListener('click', () => info('Your camera, your privacy.', [
  'Preview runs entirely locally on your device in your browser.',
  'Analyze sends 1 to 8 bounded frames to the backend hybrid recognizer. Footage is kept in memory only for inference and is never saved to disk or logged.',
  'Text-to-speech uses your device’s built-in browser synthesis without transmitting audio.',
  'Clear Transcript resets session memory at any time.'
]));

$('aboutButton').addEventListener('click', () => info('SignBridge Connect — Hybrid Architecture', [
  'SignBridge Connect combines dual streams: high-dimensional spatial-temporal RGB video frames with low-dimensional MediaPipe kinematic landmarks (hands + upper pose).',
  'By fusing these representations with gated attention, the model overcomes unimodal failure modes: landmark ambiguity under self-occlusion is resolved by RGB appearance, while background clutter is filtered by the landmark geometric prior.',
  'Uncertainty preservation is strictly enforced: when visual confidence is low, the system abstains or tags hypotheses as uncertain rather than allowing generative models to invent fictitious translations.',
  'The Comparative Validation Lab benchmarks these trade-offs directly against isolated unimodal baselines.'
]));

window.addEventListener('resize', resizeOverlay);
window.addEventListener('pagehide', stop);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { stop(); clearInterval(healthTimer); }
  else { health(); healthTimer = setInterval(() => { if (!busy) health(); }, 60000); }
});

// Navigation link active state
document.querySelectorAll('nav a.nav-item').forEach(link => {
  link.addEventListener('click', () => {
    document.querySelectorAll('nav a.nav-item').forEach(l => l.classList.remove('active'));
    link.classList.add('active');
  });
});

// Initialize
renderCustomSigns();
controls();
health(true);
healthTimer = setInterval(() => { if (!busy) health(); }, 60000);
