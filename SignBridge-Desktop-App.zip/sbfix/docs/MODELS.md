# Connect actual inference

No provider is silently chosen. No token is included. The frontend calls only its own `/api` routes; `.env` is outside the static directory and is not served.

## General gestures and visible expressions: vision endpoint

Use a provider or self-hosted service that actually serves a **vision-language model**, supports the OpenAI-compatible **`POST /v1/chat/completions`** format, accepts **multiple base64 `image_url` content blocks**, and returns structured JSON following the supplied schema. An ordinary text LLM cannot substitute. Model IDs vary by host; a Hugging Face repository ID is not itself an inference endpoint.

In the project root `.env`:

```dotenv
VLM_BASE_URL=https://YOUR-REAL-PROVIDER-HOST/v1
VLM_MODEL=YOUR-EXACT-SERVED-VISION-MODEL-ID
VLM_API_KEY=YOUR-PRIVATE-PROVIDER-API-TOKEN
VLM_ALLOW_NO_KEY=false
```

The URL above is a placeholder: obtain a working base URL, model ID and API token from your provider dashboard. The required token is a **model inference API token**, not a GitHub token. For a gated Hugging Face model, the inference host may additionally need its own server-side `HF_TOKEN`; that is not automatically interchangeable with the request API key. Never paste private keys into the web UI or commit them.

The adapter appends `/chat/completions` to the configured base URL. Check connection uses `/models`; some hosts do not implement model listing, so a failed probe alone does not prove inference is impossible. Actual image inference is only tested by Analyze. Incompatible JSON results are rejected rather than displayed as translations.

### Self-host Qwen with vLLM (GPU machine)

This is a deployment recipe, **not a VLM runtime tested in the current CPU sandbox**. Use a Linux CUDA host with a compatible current vLLM release supporting Qwen2.5-VL. Check vLLM's supported CUDA/PyTorch combinations before installing. A 24GB GPU is a reasonable starting estimate for the 7B model at limited image resolution; benchmark actual memory/latency before live use.

```sh
vllm serve Qwen/Qwen2.5-VL-7B-Instruct \
  --host 127.0.0.1 --port 8001 \
  --max-model-len 8192 \
  --limit-mm-per-prompt '{"image":8}' \
  --mm-processor-kwargs '{"min_pixels":200704,"max_pixels":200704}'
```

For the web backend on the **same host**, configure:

```dotenv
VLM_BASE_URL=http://127.0.0.1:8001/v1
VLM_MODEL=Qwen/Qwen2.5-VL-7B-Instruct
VLM_ALLOW_NO_KEY=true
```

Keep unauthenticated vLLM bound to loopback. To use it remotely, add authentication and HTTPS at the model host, set `VLM_API_KEY` and `VLM_ALLOW_NO_KEY=false`. Never expose an unauthenticated GPU endpoint to the internet. Multi-image support and the JSON contract must be verified against the chosen serving version. The app sends eight separate ordered images and timestamps, not a native video file; this provides sparse temporal evidence but can miss fast motion.

Model license: the inspected 7B model card states Apache 2.0. Verify current model/serving licenses and managed-host terms. GPU hosting, bandwidth, and tokens can cost money. No free inference allocation is bundled. CPU-only testing in this sandbox does not establish acceptable live latency.

## ISL: private trained Sanket worker

### Exact required assets

Point `SANKET_ROOT` to the **Sanket - ISL Translator** directory containing:

```text
architecture.py
extract_features.py
INCLUDE_Labels.csv
weights/model_best.pth
cache/t5-base/config.json
cache/t5-base/model.safetensors          # or compatible complete weight shards/bin
cache/t5-base/tokenizer_config.json
cache/t5-base/spiece.model              # tokenizer.json may also be present
cache/t5-base/special_tokens_map.json    # when produced by tokenizer save
cache/timesformer/config.json
cache/timesformer/model.safetensors     # or compatible complete weight shards/bin
```

The tokenizer vocabulary/config must match the checkpoint. Empty cache directories or config files alone are insufficient. `setup_cache.py` creates these caches. `app.py` and `gemini_nlp.py` are not required by this worker; the original Gemini polishing path is not used. The model may also require MediaPipe's Holistic pose assets, installed/downloaded by MediaPipe on first use. No VLM token is required for local Sanket inference.

### Windows worker setup

Install Git for Windows. Open Command Prompt in the extracted **new app** folder, separate from your existing working Sanket copy:

```bat
py -3.11 -m venv .sanket-venv
.sanket-venv\Scripts\python -m pip install torch==2.8.0 torchvision==0.23.0 --index-url https://download.pytorch.org/whl/cpu
.sanket-venv\Scripts\python -m pip install -r requirements-sanket.txt
.sanket-venv\Scripts\python scripts\setup_sanket.py --download-checkpoint
```

This downloads several GB and preserves existing files. The source is pinned to the inspected upstream revision. The public checkpoint is a candidate; see the validation findings below. To use your local checkpoint instead, omit `--download-checkpoint` and put your matching file in `weights/model_best.pth`. For CUDA, install the matching supported torch/torchvision build for your driver instead of the CPU command. Keep this environment separate from the small web environment.

Set these in the web project's `.env` using your actual absolute path:

```dotenv
SANKET_ROOT=C:/SignBridgeConnect/sanket-upstream/Sanket - ISL Translator
SANKET_URL=http://127.0.0.1:8765
```

In a second terminal from the project root:

```bat
.sanket-venv\Scripts\python -m uvicorn backend.sanket_worker:app --host 127.0.0.1 --port 8765 --workers 1
```

Keep both terminals open and restart the main website server after `.env` changes. Open `http://127.0.0.1:8765/health`: `model_loaded: true` means strict initialization succeeded. It does **not** mean sign accuracy was validated. If false, the worker's terminal logs describe the failure. Missing or incompatible files never trigger random-weight inference. The worker is private and unauthenticated: do not expose port 8765 publicly.

Choose ISL in the website and capture one isolated sign in an eight-frame sequence. Current ISL results are uncertain decoder hypotheses. Unknown is returned if hands are insufficiently visible or output is outside the complete INCLUDE label vocabulary. The current worker cannot calibrate confidence, align exact glosses, or establish a full sentence; it abstains in column B and disables AI Guess Mode for ISL.

### Compatibility findings

The public checkpoint at Hugging Face revision `e62628f263f014833dd9a00bddf8c07b42a18ebb` **strictly loaded successfully** against the inspected source. It contains 541 state tensors and uses 259 INCLUDE labels. A real forward pass and T5 decoder ran on synthetic input with finite embeddings. This verifies numerical execution, not sign accuracy. The HTTP worker also returned unknown on a hand-only test image with insufficient signer context. No labeled real-signing clip was available.

To repeat the numerical check after setting `SANKET_ROOT`, run `.sanket-venv\Scripts\python scripts\check_sanket.py`. Final results are recorded in `VALIDATION.md`. The user's local checkpoint was not supplied; a public candidate from `ayush2635/sanket-isl-translator` was inspected separately. If your local model is different, provide its checkpoint **together with matching architecture, label CSV, tokenizer assets, training configuration, and one labeled test clip**. Do not upload private tokens or virtual environments.

## WSL and future languages

The WSL selector intentionally reports unavailable. Please confirm what WSL means, the relevant sign-language standard/region, and the intended dataset. No expansion of the abbreviation is assumed. A new language needs an appropriate trained sequence model and its evaluation data. It cannot be enabled safely by changing the prompt or relabeling ISL output.

### One-click Windows setup (added in this build)
Run `SETUP-ISL-WORKER.bat` once. It creates an isolated Python 3.11 environment, downloads the CPU PyTorch stack, pinned upstream source, tokenizer/model caches and the public checkpoint candidate, then writes the local `SANKET_ROOT` and `SANKET_URL` settings into `.env`. This download is several GB and requires internet access and disk space. Then run `START-SIGNBRIDGE-WITH-ISL.bat`; it starts the private worker on loopback, waits for `/health` to report `model_loaded: true`, and only then starts the website. If the health check fails, read the Sanket worker terminal: do not treat ISL mode as ready unless the checkpoint loaded. This verifies loading, not real-world recognition accuracy.

## Sentence generation for recognized ISL glosses

The Sanket checkpoint currently emits an isolated vocabulary-label hypothesis per eight-frame clip; it does not produce validated continuous ISL sentences by itself. SignBridge accumulates distinct successive labels and can realize that label sequence into concise English using an optional text model. Configure this in the server-side `.env`:

```dotenv
LLM_BASE_URL=http://127.0.0.1:11434/v1
LLM_MODEL=llama3.2:3b
LLM_API_KEY=
```

This example assumes a local Ollama service with the named model pulled and an OpenAI-compatible endpoint enabled. Use the exact model and endpoint available on your machine. The LLM is a grammar/realization layer, not an ISL recognizer: it cannot repair incorrect Sanket labels, and it must not be treated as a verified translation. Without a configured text model, only a small conservative grammar fallback is available.

Live capture samples the required eight Sanket frames at shorter intervals and defaults to a 0.5-second pause before the next request. This reduces avoidable capture/wait time and repeated sentence-model calls, but total latency is still bounded by Sanket inference and the optional text model. The upstream Sanket implementation requires eight frames and is not a two-frame recognizer.


## Connection and sentence fallback patch

This build defaults the private worker URL to `http://127.0.0.1:8765` and discovers `sanket-upstream/Sanket - ISL Translator` relative to the app if `SANKET_ROOT` is blank. The ISL launcher repairs blank/missing Sanket settings while preserving other `.env` values. Sentence realization defaults to the local Ollama OpenAI-compatible endpoint `http://127.0.0.1:11434/v1` with model `llama3.2:3b`. If Ollama is not reachable, SignBridge falls back to a constrained grammar rule where possible; otherwise it displays a readable `Recognized signs: ...` gloss list, explicitly marked as not a verified translation. Make sure the model named in `LLM_MODEL` is actually installed in Ollama.


### Troubleshooting: “Model provider is unreachable or returned invalid JSON”

The ISL launcher in this build explicitly rewrites `SANKET_ROOT` to the bundled Sanket directory and `SANKET_URL` to `http://127.0.0.1:8765`, preventing an old `.env` value from pointing to the website server or a stale worker. It preserves all unrelated `.env` settings. If the worker cannot be reached, the UI now reports the endpoint and a hint to check `http://127.0.0.1:8765/health`. If the response is not JSON, it reports the HTTP endpoint and a short response preview. Do not expose port 8765 beyond loopback.
