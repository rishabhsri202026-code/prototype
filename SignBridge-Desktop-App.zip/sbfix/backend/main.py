import asyncio
import json
import logging
import secrets
import time
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import Settings
from .providers import analyze_isl, analyze_vision, request_json
from .hybrid_engine import analyze_hybrid
from .benchmark import run_comparative_benchmark
from .sentences import PhraseRequest, compose
from .schemas import (
    AnalysisRequest,
    AnalysisResult,
    InterpretRequest,
    InterpretResult,
)

logger = logging.getLogger("signbridge")


class BodyLimit:
    """Enforce byte limits even for chunked requests, before JSON parsing."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["method"] != "POST":
            return await self.app(scope, receive, send)
        body = bytearray()
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            body.extend(message.get("body", b""))
            if len(body) > 3_700_000:
                return await JSONResponse({"detail": "Request too large; maximum 3.7 MB."}, 413)(scope, receive, send)
            if not message.get("more_body"):
                break
        delivered = False

        async def replay():
            nonlocal delivered
            if delivered:
                return await receive()
            delivered = True
            return {"type": "http.request", "body": bytes(body), "more_body": False}
        await self.app(scope, replay, send)


def create_app(settings=None, transport=None):
    settings = settings or Settings.from_env()

    @asynccontextmanager
    async def lifespan(app):
        async with httpx.AsyncClient(timeout=settings.timeout, transport=transport, follow_redirects=False) as client:
            app.state.client = client
            yield

    app = FastAPI(title="SignBridge Connect", lifespan=lifespan, docs_url=None, redoc_url=None)
    app.add_middleware(BodyLimit)
    gate = asyncio.Lock()
    last_request = 0.0

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, exc):
        return JSONResponse({"detail": "Invalid analysis request", "errors": [{"location": [str(part) for part in item.get("loc", [])], "message": item.get("msg", "Invalid value"), "type": item.get("type", "validation_error")} for item in exc.errors()]}, 422)

    @app.middleware("http")
    async def headers_and_origin(request, call_next):
        origin = request.headers.get("origin")
        expected = settings.public_origin or str(request.base_url).rstrip("/")
        if request.method == "POST" and origin and origin != expected:
            return JSONResponse({"detail": "Origin not allowed."}, 403)
        response = await call_next(request)
        response.headers.update({
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer",
            "Permissions-Policy": "camera=(self), microphone=()",
            "Content-Security-Policy": (
                "default-src 'self'; "
                "img-src 'self' data: blob:; "
                "media-src 'self' blob:; "
                "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
                "font-src 'self' https://fonts.gstatic.com; "
                "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net 'wasm-unsafe-eval'; "
                "worker-src 'self' blob:; "
                "connect-src 'self' https://cdn.jsdelivr.net https://storage.googleapis.com; "
                "frame-src https://www.youtube-nocookie.com; "
                "frame-ancestors 'none'"
            ),
        })
        return response

    async def authorize(request: Request):
        if settings.password:
            supplied = request.headers.get("authorization", "")
            if not secrets.compare_digest(supplied.encode(), ("Bearer " + settings.password).encode()):
                raise HTTPException(401, "Enter the app access password to analyze frames.")

    @app.get("/api/health")
    async def health():
        issue = settings.vision_issue()
        return {
            "backend": "ready",
            "authentication_required": bool(settings.password),
            "vision": {
                "state": "unconfigured" if issue else "configured_unverified",
                "model": settings.vlm_model,
                "detail": issue or "Configured. Use Check connection; actual image inference is verified only after analysis.",
            },
            "isl": {
                "state": "configured_unverified" if settings.sanket_url else "unavailable",
                "detail": "Use Check connection to inspect the worker." if settings.sanket_url else "Sanket checkpoint and worker not configured.",
            },
            "hybrid": {
                "state": "ready",
                "detail": "Hybrid RGB + Landmark engine active with uncertainty preservation.",
            },
            "wsl": {
                "state": "unavailable",
                "detail": "Dataset and intended language standard need confirmation.",
            },
            "privacy": "Frames are sent to the configured inference services only when you analyze. This server does not save frames or transcripts.",
        }

    @app.post("/api/models/check", dependencies=[Depends(authorize)])
    async def check():
        result = {}
        async with httpx.AsyncClient(timeout=5, transport=transport) as client:
            if settings.vision_issue():
                result["vision"] = {"state": "unconfigured", "detail": settings.vision_issue()}
            else:
                try:
                    headers = {"Authorization": f"Bearer {settings.vlm_key}"} if settings.vlm_key else {}
                    data = await request_json(client, "GET", settings.vlm_url + "/models", headers=headers)
                    found = any(item.get("id") == settings.vlm_model for item in data.get("data", []) if isinstance(item, dict))
                    result["vision"] = {"state": "reachable" if found else "unverified", "detail": "Model listed; image inference still requires an analysis." if found else "Provider reachable but configured model was not listed."}
                except (HTTPException, AttributeError, TypeError) as exc:
                    result["vision"] = {"state": "error", "detail": exc.detail if isinstance(exc, HTTPException) else "Invalid provider model list."}
            if settings.sanket_url:
                try:
                    data = await request_json(client, "GET", settings.sanket_url + "/health")
                    ready = isinstance(data, dict) and data.get("model_loaded") is True
                    result["isl"] = {"state": "loaded" if ready else "unavailable", "detail": "Checkpoint loaded; accuracy remains unvalidated." if ready else "Worker has no loaded model. Check its local logs and required files."}
                except HTTPException as exc:
                    result["isl"] = {"state": "error", "detail": exc.detail}
            else:
                result["isl"] = {"state": "unavailable", "detail": "Sanket worker not configured."}
            result["hybrid"] = {"state": "ready", "detail": "Local hybrid multimodal stream available."}
        return result

    @app.post("/api/sentence", dependencies=[Depends(authorize)])
    async def sentence(payload: PhraseRequest):
        # Sanket outputs label/gloss hypotheses, not English sentences. If a text LLM
        # is configured, realize the accumulated gloss sequence into cautious English.
        # Keep the local grammar fallback available when no LLM is configured.
        if settings.llm_url and settings.llm_model and payload.signs:
            system = (
                "You convert a sequence of recognized Indian Sign Language (ISL) gloss/label hypotheses "
                "into a short, grammatical English sentence. The labels may be noisy or incomplete. "
                "Preserve the meaning supported by the labels; do not add events, objects, people, tense, "
                "or intent that the sequence does not support. If the sequence is too ambiguous for a "
                "sentence, return a conservative short phrase rather than inventing meaning. "
                "Output JSON only with one key: sentence (string)."
            )
            headers = {"Authorization": f"Bearer {settings.llm_key}"} if settings.llm_key else {}
            try:
                data = await request_json(
                    app.state.client, "POST", settings.llm_url + "/chat/completions",
                    headers=headers,
                    json={"model": settings.llm_model,
                          "messages": [{"role": "system", "content": system},
                                       {"role": "user", "content": json.dumps({
                                           "recognized_isl_gloss_hypotheses": payload.signs,
                                           "instruction": "Return one concise English sentence based only on these hypotheses. If they do not support a full sentence, return a natural short phrase that preserves the labels without inventing missing meaning."
                                       })}],
                          "temperature": 0.1, "max_tokens": 100},
                )
            except HTTPException:
                # Keep the UI readable if Ollama is stopped; do not pretend the glosses are a translation.
                fallback = compose(payload.signs)
                if fallback.get("sentence"):
                    return fallback
                clean = [word.strip() for word in payload.signs if word.strip()]
                if clean:
                    return {"sentence": "Recognized signs: " + ", ".join(clean) + ".",
                            "grammar_additions": [],
                            "detail": "Ollama/text model unavailable; this is a readable gloss list, not a verified English translation.",
                            "provenance": "Fallback from unverified Sanket label hypotheses."}
                raise
            try:
                raw = data["choices"][0]["message"]["content"].strip()
                if raw.startswith("```"):
                    raw = raw.split("\\n", 1)[-1].rsplit("```", 1)[0].strip()
                obj = json.loads(raw)
                sentence_text = str(obj.get("sentence", "")).strip()[:500]
                if not sentence_text or not any(ch.isalpha() for ch in sentence_text):
                    raise ValueError("empty sentence")
            except (KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError) as exc:
                raise HTTPException(502, "Text model returned an invalid sentence. No output was accepted.") from exc
            return {"sentence": sentence_text, "grammar_additions": [],
                    "detail": "Draft generated from recognized ISL label hypotheses; verify against the signs.",
                    "provenance": "LLM sentence realization from unverified Sanket gloss hypotheses."}
        return compose(payload.signs)

    @app.get("/api/benchmark", dependencies=[Depends(authorize)])
    async def benchmark_get():
        return run_comparative_benchmark()

    @app.post("/api/benchmark", dependencies=[Depends(authorize)])
    async def benchmark_post(payload: AnalysisRequest = None):
        frames = payload.frames if payload else None
        return run_comparative_benchmark(frames=frames)

    @app.get("/api/llm/status")
    async def llm_status():
        return {
            "configured": bool(settings.llm_url and settings.llm_model),
            "base_url": settings.llm_url,
            "model": settings.llm_model,
            "detail": "LLM endpoint configured; use Interpret with LLM to verify a live response." if settings.llm_url else "Set LLM_BASE_URL and LLM_MODEL in .env.",
        }

    @app.post("/api/interpret", response_model=InterpretResult, dependencies=[Depends(authorize)])
    async def interpret(payload: InterpretRequest):
        if not settings.llm_url or not settings.llm_model:
            # Conservative local fallback preserves uncertainty
            joined = " · ".join(payload.gestures) if payload.gestures else "No gestures"
            return InterpretResult(
                status="local_rule_based",
                model="SignBridge Conservative Synthesizer",
                interpretation=f"Observed gesture sequence: {joined}. Uncertainty preserved; no ungrounded claims generated.",
                suggestions=["Sign observed again to confirm"] if payload.guess_mode else [],
                note="Uncertainty preserved: Model abstains from inventing unverified sign language sentences.",
            )
        system = (
            "You are the language layer in a hand-gesture communication prototype. "
            "The inputs are generic computer-vision pose labels, NOT verified sign-language glosses. "
            "Never claim these are ISL signs or invent the person's intent. "
            "Explain the observable sequence conservatively in one short sentence. "
            "If guess_mode is true, offer up to three clearly tentative everyday interpretations as suggestions only; "
            "if false, return no suggestions. Output JSON only with keys interpretation (string), suggestions (array of strings)."
        )
        user = {
            "recognized_pose_sequence": payload.gestures,
            "guess_mode": payload.guess_mode,
            "instruction": "Do not translate these labels as sign language. State the limits clearly.",
        }
        headers = {"Authorization": f"Bearer {settings.llm_key}"} if settings.llm_key else {}
        data = await request_json(
            app.state.client,
            "POST",
            settings.llm_url + "/chat/completions",
            headers=headers,
            json={
                "model": settings.llm_model,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": json.dumps(user)}],
                "temperature": 0.2,
                "max_tokens": 350,
            },
        )
        try:
            raw = data["choices"][0]["message"]["content"].strip()
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
            obj = json.loads(raw)
            interpretation = str(obj.get("interpretation", ""))[:500]
            suggestions = [str(x)[:200] for x in obj.get("suggestions", [])[:3]] if payload.guess_mode else []
            if not interpretation:
                raise ValueError("empty")
        except (KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError) as exc:
            raise HTTPException(502, "LLM returned an invalid response. No interpretation was accepted.") from exc
        return InterpretResult(
            status="connected",
            model=settings.llm_model,
            interpretation=interpretation,
            suggestions=suggestions,
            note="LLM processed generic pose labels, preserving uncertainty.",
        )

    @app.post("/api/analyze", response_model=AnalysisResult, dependencies=[Depends(authorize)])
    async def analyze(payload: AnalysisRequest):
        nonlocal last_request
        if payload.language == "wsl":
            raise HTTPException(422, "WSL is unavailable until its language standard, dataset, and trained model are confirmed.")
        if gate.locked():
            raise HTTPException(429, "An analysis is already running. Wait for it to finish.")
        minimum_interval = 0.5 if payload.language in ("isl", "hybrid") else 2.0
        if time.monotonic() - last_request < minimum_interval:
            raise HTTPException(429, f"Please wait {minimum_interval:g} seconds between analyses.")
        async with gate:
            last_request = time.monotonic()
            started = time.monotonic()
            try:
                if payload.language == "hybrid":
                    provider = analyze_hybrid
                elif payload.language == "isl":
                    provider = analyze_isl
                else:
                    provider = analyze_vision
                result = await provider(payload, settings, app.state.client)
                logger.info("analysis_complete language=%s frames=%d duration=%.2fs", payload.language, len(payload.frames), time.monotonic() - started)
                return result
            except HTTPException as exc:
                logger.warning("analysis_failed status=%d language=%s", exc.status_code, payload.language)
                raise

    app.mount("/", StaticFiles(directory=Path(__file__).resolve().parent.parent / "frontend", html=True), name="frontend")
    return app


app = create_app()
