import base64
import io
import json
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient
from PIL import Image

from backend.config import Settings, validate_url
from backend.main import create_app
from backend.sanket_worker import SanketEngine


def payload(count=1, **kwargs):
    buf = io.BytesIO()
    Image.new("RGB", (64, 64), "white").save(buf, "JPEG")
    image = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    return {"frames": [{"image": image, "timestamp_ms": i * 400} for i in range(count)], **kwargs}


def inference(**overrides):
    result = {"observations": [{"kind": "hand", "label": "Open palm", "meaning": "Visible palm", "certainty": "clear"}],
              "sentence": "An open palm is visible.", "suggestions": [{"text": "Possibly a greeting", "reason": "Context is ambiguous", "certainty": "uncertain"}]}
    result.update(overrides)
    return httpx.Response(200, json={"choices": [{"message": {"content": json.dumps(result)}}]})


def configured(handler):
    return create_app(Settings(vlm_url="http://127.0.0.1:8001/v1", vlm_key="test-only-secret"), httpx.MockTransport(handler))


def test_missing_configuration_and_health():
    with TestClient(create_app(Settings())) as client:
        health = client.get("/api/health")
        assert health.status_code == 200
        assert health.json()["vision"]["state"] == "unconfigured"
        response = client.post("/api/analyze", json=payload())
        assert response.status_code == 503
        assert "VLM_BASE_URL" in response.json()["detail"]
        assert "observations" not in response.json()


def test_missing_token_returns_helpful_configuration_error():
    with TestClient(create_app(Settings(vlm_url="https://example.com/v1"))) as client:
        response = client.post("/api/analyze", json=payload())
        assert response.status_code == 503
        assert "VLM_API_KEY" in response.text


@pytest.mark.parametrize("guess", [False, True])
def test_real_image_protocol_and_guess_enforcement(guess):
    captured = []
    def provider(request):
        captured.append(request)
        return inference()
    with TestClient(configured(provider)) as client:
        response = client.post("/api/analyze", json=payload(8, guess_mode=guess))
        assert response.status_code == 200
        assert bool(response.json()["suggestions"]) == guess
        assert response.json()["motion_analyzed"] is True
        assert response.json()["sentence"] == "An open palm is visible."
    sent = json.loads(captured[0].content)
    images = [item for item in sent["messages"][1]["content"] if item["type"] == "image_url"]
    assert len(images) == 8
    assert images[0]["image_url"]["url"].startswith("data:image/jpeg;base64,")
    assert captured[0].headers["authorization"] == "Bearer test-only-secret"
    assert "test-only-secret" not in response.text


def test_still_frame_cannot_report_motion_or_sign_translation():
    observations = [{"kind": kind, "label": "Wave", "meaning": "hello", "certainty": "clear"} for kind in ["movement", "sign"]]
    with TestClient(configured(lambda request: inference(observations=observations))) as client:
        result = client.post("/api/analyze", json=payload()).json()
        assert result["observations"] == [] and result["sentence"] is None
        assert result["motion_analyzed"] is False and result["suggestions"] == []


def test_uncertain_evidence_cannot_form_confident_sentence():
    observations = [{"kind": "hand", "label": "unclear", "meaning": "", "certainty": "uncertain"}]
    with TestClient(configured(lambda request: inference(observations=observations))) as client:
        assert client.post("/api/analyze", json=payload()).json()["sentence"] is None


@pytest.mark.parametrize("status,expected", [(401, "API key"), (429, "usage limit"), (500, "provider returned an error")])
def test_provider_errors_are_sanitized(status, expected):
    with TestClient(configured(lambda request: httpx.Response(status, text="sensitive upstream diagnostics"))) as client:
        result = client.post("/api/analyze", json=payload())
        assert result.status_code == 502 and expected in result.text
        assert "sensitive" not in result.text


def test_provider_timeout():
    def provider(request):
        raise httpx.ReadTimeout("timeout", request=request)
    with TestClient(configured(provider)) as client:
        assert client.post("/api/analyze", json=payload()).status_code == 504


def test_invalid_provider_schema_is_not_accepted():
    with TestClient(configured(lambda request: httpx.Response(200, json={"choices": []}))) as client:
        assert client.post("/api/analyze", json=payload()).status_code == 502


@pytest.mark.parametrize("mutation", ["invalid_image", "too_many", "bad_timestamp", "oversized_image", "bad_language"])
def test_invalid_client_input(mutation):
    request = payload(8)
    if mutation == "invalid_image": request["frames"][0]["image"] = "SECRET_INVALID_CAMERA_BYTES"
    if mutation == "too_many": request["frames"] *= 2
    if mutation == "bad_timestamp": request["frames"][1]["timestamp_ms"] = 0
    if mutation == "oversized_image":
        buf = io.BytesIO(); Image.new("RGB", (1600, 32)).save(buf, "JPEG")
        request["frames"][0]["image"] = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    if mutation == "bad_language": request["language"] = "invented"
    with TestClient(create_app(Settings())) as client:
        result = client.post("/api/analyze", json=request)
        assert result.status_code == 422 and "SECRET_INVALID" not in result.text


def test_request_body_limit():
    with TestClient(create_app(Settings())) as client:
        assert client.post("/api/analyze", content=b"x" * 3_700_001).status_code == 413


def test_password_origin_and_public_static_files():
    with TestClient(create_app(Settings(password="test-password"))) as client:
        assert client.post("/api/analyze", json=payload()).status_code == 401
        assert client.post("/api/analyze", json=payload(), headers={"Origin": "https://evil.example"}).status_code == 403
        assert client.post("/api/analyze", json=payload(), headers={"Authorization": "Bearer test-password"}).status_code == 503
        assert client.get("/.env").status_code == 404
        assert client.get("/backend/config.py").status_code == 404
        assert client.get("/").status_code == 200
        assert "/api/analyze" in client.get("/openapi.json").json()["paths"]
        assert client.get("/docs").status_code == 404
        assert "frame-ancestors 'none'" in client.get("/").headers["content-security-policy"]


def test_isl_and_wsl_are_not_guessed_by_vlm():
    with TestClient(create_app(Settings())) as client:
        response = client.post("/api/analyze", json=payload(8, language="wsl"))
        assert response.status_code == 422 and "standard" in response.text
        response = client.post("/api/analyze", json=payload(8, language="isl"))
        assert response.status_code == 503 and "Sanket" in response.text


def test_isl_worker_contract_does_not_promote_uncalibrated_predictions():
    data = {"observations": [{"kind": "sign", "label": "water", "meaning": "water", "certainty": "clear"}],
            "sentence": "I need water", "suggestions": [], "source": "Sanket", "frame_count": 8,
            "motion_analyzed": True, "interpretation": "hypothesis", "warnings": []}
    with TestClient(create_app(Settings(sanket_url="http://127.0.0.1:8765"), httpx.MockTransport(lambda request: httpx.Response(200, json=data)))) as client:
        response = client.post("/api/analyze", json=payload(8, language="isl", guess_mode=True))
        assert response.status_code == 200
        assert response.json()["sentence"] is None
        assert response.json()["observations"][0]["certainty"] == "uncertain"


def test_sanket_missing_files_never_reports_loaded(tmp_path):
    engine = SanketEngine(tmp_path)
    engine.load()
    assert engine.model is None
    for filename in ["architecture.py", "extract_features.py", "INCLUDE_Labels.csv", "weights/model_best.pth", "cache/t5-base/config.json", "cache/timesformer/config.json"]:
        assert filename in engine.error


def test_models_endpoint_does_not_claim_inference_verified():
    with TestClient(configured(lambda request: httpx.Response(200, json={"data": [{"id": "Qwen/Qwen2.5-VL-7B-Instruct"}]}))) as client:
        response = client.post("/api/models/check")
        assert response.json()["vision"]["state"] == "reachable"
        assert "still requires" in response.json()["vision"]["detail"]


def test_rate_limit():
    with TestClient(configured(lambda request: inference())) as client:
        assert client.post("/api/analyze", json=payload()).status_code == 200
        assert client.post("/api/analyze", json=payload()).status_code == 429


@pytest.mark.parametrize("url", ["http://example.com/v1", "https://secret:token@example.com/v1", "file:///etc/passwd"])
def test_provider_url_safety(url):
    with pytest.raises(ValueError): validate_url(url)


def test_concurrent_analysis_is_rejected():
    import asyncio
    import threading
    from concurrent.futures import ThreadPoolExecutor
    entered = threading.Event()
    async def provider(request):
        entered.set()
        await asyncio.sleep(0.3)
        return inference()
    with TestClient(configured(provider)) as client, ThreadPoolExecutor(max_workers=2) as pool:
        first = pool.submit(client.post, "/api/analyze", json=payload())
        assert entered.wait(2)
        second = client.post("/api/analyze", json=payload())
        assert second.status_code == 429 and "already running" in second.text
        assert first.result().status_code == 200
