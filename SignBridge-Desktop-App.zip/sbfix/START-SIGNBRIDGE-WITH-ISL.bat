@echo off
setlocal
cd /d "%~dp0"
if not exist ".sanket-venv\Scripts\python.exe" (echo Sanket worker is not installed. Run SETUP-ISL-WORKER.bat first.& pause & exit /b 1)
if not exist "sanket-upstream\Sanket - ISL Translator\weights\model_best.pth" (echo Sanket checkpoint is missing. Run SETUP-ISL-WORKER.bat first.& pause & exit /b 1)
if not exist ".env" copy ".env.example" ".env" >nul
REM Repair missing/blank worker settings in an existing .env without overwriting other user settings.
".sanket-venv\Scripts\python.exe" -c "from pathlib import Path; p=Path('.env'); s=p.read_text(encoding='utf-8') if p.exists() else ''; d={'SANKET_ROOT':(Path('sanket-upstream')/'Sanket - ISL Translator').resolve().as_posix(),'SANKET_URL':'http://127.0.0.1:8765'}; lines=[x for x in s.splitlines() if not any(x.startswith(k+'=') for k in d)]; lines += [k+'='+v for k,v in d.items()]; p.write_text('\n'.join(lines)+'\n',encoding='utf-8'); print('Forced local Sanket worker URL and discovered checkpoint path in .env')"
if errorlevel 1 goto fail
if not exist ".venv\Scripts\python.exe" py -3.11 -m venv .venv
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto fail
start "SignBridge Sanket ISL Worker" cmd /k "cd /d "%~dp0" && .sanket-venv\Scripts\python.exe -m uvicorn backend.sanket_worker:app --host 127.0.0.1 --port 8765 --workers 1"
echo Waiting for Sanket worker to load its checkpoint (up to 6 minutes)...
".venv\Scripts\python.exe" scripts\wait_sanket.py
if errorlevel 1 (echo Sanket worker did not become ready. Check the worker terminal; see docs\MODELS.md.& pause & exit /b 1)
".venv\Scripts\python.exe" scripts\launch.py
pause
exit /b 0
:fail
echo SignBridge setup failed. Read the error above.
pause
exit /b 1
