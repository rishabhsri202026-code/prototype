@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo =====================================================
echo SignBridge - Install the real Sanket ISL model worker
echo =====================================================
echo This downloads Python packages and several GB of model files.
echo Keep this window open and ensure you have enough disk space.
echo.
where py >nul 2>nul
if errorlevel 1 (echo Python launcher 'py' not found. Install Python 3.11 64-bit first.& pause & exit /b 1)
if not exist ".sanket-venv\Scripts\python.exe" py -3.11 -m venv .sanket-venv
if errorlevel 1 goto fail
".sanket-venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto fail
".sanket-venv\Scripts\python.exe" -m pip install torch==2.8.0 torchvision==0.23.0 --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto fail
".sanket-venv\Scripts\python.exe" -m pip install -r requirements-sanket.txt
if errorlevel 1 goto fail
".sanket-venv\Scripts\python.exe" scripts\setup_sanket.py --download-checkpoint
if errorlevel 1 goto fail
".sanket-venv\Scripts\python.exe" -c "from pathlib import Path; import os; p=Path('.env'); s=p.read_text(encoding='utf-8') if p.exists() else ''; root=(Path('sanket-upstream')/'Sanket - ISL Translator').resolve().as_posix(); lines=[x for x in s.splitlines() if not x.startswith(('SANKET_ROOT=','SANKET_URL='))]; lines += ['SANKET_ROOT='+root, 'SANKET_URL=http://127.0.0.1:8765']; p.write_text('\n'.join(lines)+'\n', encoding='utf-8'); print('Configured .env for local Sanket worker:',root)"
if errorlevel 1 goto fail
echo.
echo Setup completed. Next run START-SIGNBRIDGE-WITH-ISL.bat
echo Model load may take a few minutes the first time.
pause
exit /b 0
:fail
echo.
echo Setup failed. Read the first error above; no model will be faked or substituted.
pause
exit /b 1
