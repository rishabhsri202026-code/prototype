"""Start the local server and open its page only after it is ready."""
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
def free_port(start=8000):
    # An older SignBridge may still hold port 8000; never reuse a busy port or a stale page is served.
    for port in range(start, start + 50):
        with socket.socket() as probe:
            probe.settimeout(0.3)
            if probe.connect_ex(("127.0.0.1", port)) == 0:
                continue
        with socket.socket() as probe:
            try:
                probe.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise SystemExit("No free port found between 8000 and 8049.")

PORT = free_port()
URL = f"http://localhost:{PORT}"
process = subprocess.Popen([sys.executable, "-m", "uvicorn", "backend.main:app", "--host", "127.0.0.1", "--port", str(PORT)], cwd=ROOT)
try:
    for _ in range(80):
        if process.poll() is not None:
            raise SystemExit("The server could not start. Read the error above; ")
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/api/health", timeout=1) as response:
                if response.status == 200:
                    # Allow an immediate bind failure to surface before opening an unrelated app.
                    time.sleep(0.3)
                    if process.poll() is not None:
                        raise SystemExit("The server stopped right after starting. Read the error above.")
                    webbrowser.open(URL)
                    print(f"SignBridge is ready at {URL}  -  keep this window open; press Ctrl+C to stop.")
                    break
        except OSError:
            time.sleep(0.25)
    else:
        raise SystemExit("The backend did not become ready. Check terminal diagnostics.")
    process.wait()
except KeyboardInterrupt:
    pass
finally:
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
