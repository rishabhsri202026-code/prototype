"""Bounded image input and strict inference output contracts."""
import base64
import io
from typing import Literal, Optional
from PIL import Image, UnidentifiedImageError
from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Frame(StrictModel):
    image: str = Field(max_length=450_000)
    timestamp_ms: int = Field(ge=0, le=15_000)
    # Optional MediaPipe hand landmarks (21 points of [x, y, z]) detected in the browser for this frame.
    landmarks: Optional[list[list[float]]] = Field(default=None, max_length=21)

    @model_validator(mode="after")
    def valid_image(self):
        if self.landmarks is not None and (len(self.landmarks) != 21 or any(len(p) != 3 or any(abs(v) > 10 for v in p) for p in self.landmarks)):
            raise ValueError("Landmarks must be 21 points of [x, y, z].")
        prefix = "data:image/jpeg;base64,"
        if not self.image.startswith(prefix):
            raise ValueError("Frames must be base64 JPEG data URLs.")
        try:
            data = base64.b64decode(self.image[len(prefix):], validate=True)
            with Image.open(io.BytesIO(data)) as image:
                if image.format != "JPEG" or not (32 <= image.width <= 1280 and 32 <= image.height <= 1280):
                    raise ValueError("JPEG dimensions must be between 32 and 1280 pixels.")
                image.verify()
        except (ValueError, OSError, UnidentifiedImageError) as exc:
            raise ValueError("Invalid or oversized JPEG frame.") from exc
        return self


class AnalysisRequest(StrictModel):
    frames: list[Frame] = Field(min_length=1, max_length=8)
    language: Literal["general", "isl", "wsl", "hybrid"] = "general"
    guess_mode: bool = False
    context: list[str] = Field(default_factory=list, max_length=5)

    @model_validator(mode="after")
    def valid_sequence(self):
        if any(len(item) > 300 for item in self.context):
            raise ValueError("Context entries must be at most 300 characters.")
        times = [frame.timestamp_ms for frame in self.frames]
        if any(b <= a for a, b in zip(times, times[1:])):
            raise ValueError("Frame timestamps must increase strictly.")
        if len(times) > 1 and times[-1] - times[0] < 80:
            raise ValueError("Multiple frames must span at least 80 ms.")
        return self


class Observation(StrictModel):
    kind: Literal["hand", "expression", "movement", "body", "sign"]
    label: str = Field(min_length=1, max_length=160)
    meaning: str = Field(max_length=300)
    certainty: Literal["clear", "uncertain", "unknown"]


class Suggestion(StrictModel):
    text: str = Field(min_length=1, max_length=300)
    reason: str = Field(max_length=300)
    certainty: Literal["uncertain", "unknown"] = "uncertain"


class VisionResult(StrictModel):
    observations: list[Observation] = Field(max_length=12)
    sentence: Optional[str] = Field(default=None, max_length=500)
    suggestions: list[Suggestion] = Field(default_factory=list, max_length=3)


class AnalysisResult(VisionResult):
    source: str
    frame_count: int
    motion_analyzed: bool
    interpretation: str
    warnings: list[str]


class InterpretRequest(StrictModel):
    gestures: list[str] = Field(default_factory=list, max_length=16)
    guess_mode: bool = False


class InterpretResult(StrictModel):
    status: str
    model: str
    interpretation: str
    suggestions: list[str] = Field(default_factory=list)
    note: str

