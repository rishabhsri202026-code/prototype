"""Wait for the local Sanket worker to report a loaded checkpoint."""
import json
import time
import urllib.request

url = "http://127.0.0.1:8765/health"
for _ in range(180):
    try:
        with urllib.request.urlopen(url, timeout=2) as response:
            data = json.loads(response.read().decode("utf-8"))
        print(data, flush=True)
        if data.get("model_loaded") is True:
            raise SystemExit(0)
    except Exception as exc:
        if isinstance(exc, SystemExit):
            raise
    time.sleep(2)
print("Sanket did not become ready within 6 minutes. Check worker logs.")
raise SystemExit(1)
