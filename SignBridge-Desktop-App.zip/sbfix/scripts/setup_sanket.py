"""Fetch pinned upstream source and caches; run in the separate worker environment."""
import argparse
import subprocess
from pathlib import Path

SOURCE_REVISION = "da2f6374ffc8b395dc6cd014edefe6720546050b"
ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description="Prepare optional Sanket assets (large downloads).")
    parser.add_argument("--download-checkpoint", action="store_true", help="Download the public checkpoint instead of supplying your own; compatibility must still be tested.")
    args = parser.parse_args()
    upstream = ROOT / "sanket-upstream"
    if not upstream.exists():
        subprocess.run(["git", "clone", "https://github.com/ayush2635/Sanket-ISL-Translator.git", str(upstream)], check=True)
        subprocess.run(["git", "checkout", SOURCE_REVISION], cwd=upstream, check=True)
    else:
        revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=upstream, text=True).strip()
        if revision != SOURCE_REVISION:
            raise SystemExit("Existing source differs from inspected revision; preserving it. Use your matching source/checkpoint or a fresh folder.")
    source = upstream / "Sanket - ISL Translator"
    from transformers import AutoModel, AutoTokenizer, T5ForConditionalGeneration
    for model_id, target, model_type in [
        ("google-t5/t5-base", source / "cache/t5-base", T5ForConditionalGeneration),
        ("facebook/timesformer-base-finetuned-k400", source / "cache/timesformer", AutoModel),
    ]:
        tokenizer_ready = "t5" not in model_id or ((target / "tokenizer_config.json").exists() and ((target / "tokenizer.json").exists() or (target / "spiece.model").exists()))
        if (target / "config.json").exists() and any(target.glob("*.safetensors")) and tokenizer_ready:
            print(f"Preserving existing cache: {target}")
            continue
        print(f"Downloading {model_id}; allow several GB of disk space.")
        model = model_type.from_pretrained(model_id)
        model.save_pretrained(target)
        del model
        if "t5" in model_id:
            AutoTokenizer.from_pretrained(model_id).save_pretrained(target)
    if args.download_checkpoint:
        from huggingface_hub import hf_hub_download
        import shutil
        checkpoint = source / "weights/model_best.pth"
        if not checkpoint.exists():
            checkpoint.parent.mkdir(exist_ok=True)
            download = hf_hub_download("ayush2635/sanket-isl-translator", "model_best.pth", revision="e62628f263f014833dd9a00bddf8c07b42a18ebb")
            shutil.copyfile(download, checkpoint)
    print("Assets prepared, NOT inference-validated. Set SANKET_ROOT and run the worker health check.")
    print(source)


if __name__ == "__main__":
    main()
