"""Conservative grammar realization, not sign recognition or an LLM substitute.

Only explicitly supported constructions are realized. Unknown grammar abstains.
No subject, intent, object or missing content word is invented.
"""
import re
from pydantic import Field, field_validator
from .schemas import StrictModel

ADJECTIVES = set("alive alright bad beautiful big black blind blue brown cheap clean cold cool curved dead deaf deep dirty dry expensive famous fast female flat good green grey happy hard healthy heavy high hot light long loose loud low male narrow new nice old orange pink pleased poor quiet red rich sad shallow short sick slow small soft strong tall thick thin tight ugly warm weak wet white wide yellow young".split())
ROLES = set("actor adult artist author baby boy brother child daughter doctor father friend girl grandfather grandmother husband king lawyer man manager mother neighbour parent patient player police president priest queen reporter secretary sister soldier son student teacher waiter wife woman".split())
PLACES = set("bank bathroom bedroom city court hospital house india kitchen library market office park restaurant school store street temple university".split())
SUBJECTS = {"i": ("I", "am"), "you": ("You", "are"), "he": ("He", "is"), "she": ("She", "is"), "it": ("It", "is"), "we": ("We", "are"), "they": ("They", "are")}


class PhraseRequest(StrictModel):
    signs: list[str] = Field(default_factory=list, max_length=16)

    @field_validator("signs")
    @classmethod
    def bounded_words(cls, value):
        if any(not re.fullmatch(r"[A-Za-z][A-Za-z '-]{0,59}", word) for word in value):
            raise ValueError("Supply sign labels, one per entry (maximum 60 characters).")
        return value


def compose(signs):
    words = [word.strip().lower() for word in signs]
    result = {"sentence": None, "grammar_additions": [], "detail": "Keep signing or correct the word list. This combination needs more evidence or an unsupported grammar rule.",
              "provenance": "Grammar draft from supplied sign hypotheses; not a verified translation."}
    if len(words) == 2 and words[0] in SUBJECTS:
        subject, copula = SUBJECTS[words[0]]
        predicate = words[1]
        if predicate in ADJECTIVES:
            result.update(sentence=f"{subject} {copula} {predicate}.", grammar_additions=[copula])
        elif predicate in ROLES and words[0] in {"i", "he", "she", "it"}:
            article = "an" if predicate[0] in "aeiou" else "a"
            result.update(sentence=f"{subject} {copula} {article} {predicate}.", grammar_additions=[copula, article])
    # Preserve explicit relational evidence; do not guess a relation from two nouns.
    if len(words) == 3 and words[0] in SUBJECTS and words[1] in {"need", "want", "like", "see", "have"} and words[2] in {"water", "food", "help", "medicine", "money"}:
        subject = SUBJECTS[words[0]][0]
        verb = words[1]
        if words[0] in {"he", "she", "it"}: verb = "has" if verb == "have" else verb + "s"
        result.update(sentence=f"{subject} {verb} {words[2]}.", grammar_additions=[])
    if result["sentence"]:
        result["detail"] = "Review the sign list before using this draft. Added function words express grammar only."
    return result
