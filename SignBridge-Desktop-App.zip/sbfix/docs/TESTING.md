# Validation and reproducible tests

## Run the automated checks

From the project root on Windows:

```bat
.venv\Scripts\python -m pip install -r requirements-dev.txt
.venv\Scripts\python -m pytest -q
.venv\Scripts\python -m pip check
```

On Linux/macOS replace `.venv\Scripts\python` with `.venv/bin/python`.

Camera lifecycle unit tests use Node 24+ and require no npm dependencies:

```sh
npm test
```

Browser integration tests use Playwright as a client attached to an **already running** Chromium browser. Start the application on port 8000, install test dependencies with `npm ci`, and set `CDP_URL` to that browser's DevTools WebSocket endpoint. Use a dedicated development browser profile when running locally. Do not enable remote debugging on a public network.

```sh
CDP_URL=ws://127.0.0.1:YOUR_PORT/devtools/browser/YOUR_ID npm run test:browser
```

PowerShell syntax: `$env:CDP_URL = "ws://..."; npm run test:browser`.

The browser checks assume the web server is **unconfigured** (no VLM settings/app password), test actual health and missing configuration, then use explicit synthetic provider fixtures. Camera tests supply a canvas MediaStream. Production code has no mock mode or canned predictions. These tests do not evaluate recognition accuracy.

## Validation carried out in the build sandbox

See `VALIDATION.md` in the project root for final results. Initial checks covered:

- Imports and dependency consistency.
- JPEG validation, temporal timestamp order, oversized bodies, unsupported languages.
- Real multimodal HTTP request construction with eight image data URLs.
- Missing endpoint/token, provider timeout/quota/auth failures and malformed output.
- Guess-mode enforcement, uncertainty suppression, removal of still-image motion/sign claims.
- Authentication, origin checks, secret-file isolation, request spacing.
- Camera track cleanup, permission races, playback failures and rear-camera constraints.
- Browser consent, start/stop/denial recovery, two-column rendering, accept/reject guesses, history clearing, cancellation, mobile overflow and provider error handling.
- Desktop/mobile visual inspection and automated accessibility scan.

## Checks still needed on your equipment

1. Test Chrome/Edge and Safari on your actual phone/laptop, including denied permissions, camera switching, interruption by another app, and page backgrounding. Browsers may satisfy a preferred front/rear constraint with the only available camera.
2. Run the Windows launcher on Windows 10/11. It was inspected here but cannot execute on Linux.
3. Run real VLM inference with your chosen provider, both one image and eight images. Confirm latency, cost, retention settings, and JSON output reliability.
4. Test a known labeled sign video against your exact checkpoint/source/cache set. Loading weights does not establish sign-recognition accuracy.
5. Before claiming model quality, evaluate held-out signers, camera conditions, hand poses (including offensive gestures), smiling/not smiling/occlusion, movement vs still controls, unknown poses, and wrong-language signs. Measure false positive rate and abstention, not only top-label accuracy. Current certainty labels are not calibrated probabilities.
6. Exercise the public HTTPS deployment from a phone and WhatsApp link. No permanent host was provisioned in this sandbox.
