@echo off
setlocal
cd /d "%~dp0"
echo Creating a SignBridge Connect shortcut on your Desktop...
set "SB_ROOT=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$WshShell = New-Object -ComObject WScript.Shell; $Desktop = [Environment]::GetFolderPath('Desktop'); $Shortcut = $WshShell.CreateShortcut((Join-Path $Desktop 'SignBridge Connect.lnk')); $Shortcut.TargetPath = Join-Path $env:SB_ROOT 'START-SIGNBRIDGE.bat'; $Shortcut.WorkingDirectory = $env:SB_ROOT; $Shortcut.Description = 'Start SignBridge Connect desktop app'; $Shortcut.Save()"
if errorlevel 1 (
  echo Shortcut creation failed. You can still double-click START-SIGNBRIDGE.bat.
  pause
  exit /b 1
)
echo.
echo Done! Double-click "SignBridge Connect" on your Desktop.
echo First launch may install Python packages and requires internet access.
echo Keep the terminal window open while using the app.
pause
