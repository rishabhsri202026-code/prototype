# SignBridge Connect

A responsive camera communication assistant with **literal observations**, **generated wording**, and separate **AI Guess Mode** predictions. FastAPI serves both the website and API from one origin, so phone browsers can use the same HTTPS link.

**The application runs without credentials, but real recognition requires an inference model. Unconfigured models produce a helpful error, never an example translation.** See [model setup](docs/MODELS.md) for exact configuration and current limitations.

## Windows: easiest start

1. Install **Python 3.11 (64-bit)** from https://www.python.org/downloads/windows/. Enable the **Python launcher (`py`)** in the installer.
2. Extract this ZIP to a folder you own, for example `C:\SignBridgeConnect`. Do not run it inside the ZIP viewer.
3. Double-click **`START-SIGNBRIDGE.bat`**. It creates `.venv`, installs the small web dependencies, creates `.env` if absent, starts the server, and opens **http://localhost:8000**. Keep the terminal open. First setup needs internet access.
4. The website should say **Backend connected**. **Vision model needs setup** is expected until you configure a model.
5. Edit `.env` with Notepad using [docs/MODELS.md](docs/MODELS.md). Keep tokens private. Restart the launcher after changes.
6. Click **Check connection**, then **Start camera** and allow permission. Select a mode, check the frame-upload consent box, and click **Analyze frame** or **Analyze sequence**.
7. Press **Stop camera** to release the camera. Close the terminal or press Ctrl+C to stop the server.

If Python is not found, run `py -3.11 --version` in Command Prompt. If port 8000 is already occupied, close the earlier server window. Do not open `frontend/index.html` directly: `file://` has no backend and camera/security behavior varies; camera access requires a secure context (HTTPS, with localhost as a browser development exception).

### Manual Windows commands

Open Command Prompt in the extracted project folder:

```bat
py -3.11 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
copy .env.example .env
.venv\Scripts\python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

Open http://localhost:8000. Do not repeat `copy` over an existing configured `.env`.

### Linux/macOS

```sh
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cp -n .env.example .env
.venv/bin/python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

## What you can use

- Front/rear camera preference, start/stop, permission errors, visible preview.
- One-frame capture for static poses; eight ordered frames for motion/ISL.
- Two interpretation columns; unknown/uncertain results and qualitative certainty.
- General vision provider with real image input, strict response validation, bounded requests, timeout/error handling.
- AI Guess Mode: separate predictions with accept/reject. Acceptance never changes observed facts.
- Controlled live analysis, tab-only transcript, clear button, optional speech synthesis, large output text, responsive layout.
- Public health at `/api/health`, authenticated provider probe at `/api/models/check`, inference at `/api/analyze`. Machine-readable API schema at `/openapi.json`.
- Optional isolated Sanket worker that uses trained RGB/pose/T5 parameters when all assets load compatibly.
- App manifest for future installable/mobile packaging; no offline inference or native app build is included.

## Honest capability status

| Capability | Status |
|---|---|
| Website, backend, camera and inference transport | Implemented and tested; browser camera tests use synthetic media. |
| General gestures / facial appearance | Actual image adapter implemented. Requires configured vision endpoint; no recognition-accuracy claim. |
| Motion such as waving | Ordered eight-image analysis implemented. Single frames cannot report movement through the result schema. |
| ISL | Trained model adapter implemented. Public checkpoint strictly loaded and real decoder smoke-tested on synthetic tensors; see `VALIDATION.md`. Results remain unverified hypotheses. |
| Exact gloss alignment / continuous phrase translation | Not supplied by this checkpoint integration; no invented exact translations. |
| Natural sentences | General-mode wording from clear observations only. Ambiguous evidence and current Sanket results abstain. |
| WSL / other sign languages | Unavailable until intended standard, trained model, and dataset are identified. |
| Real physical camera, Windows launcher, model accuracy | Must still be checked on target devices; do not mistake synthetic tests for hardware/model validation. |

## Privacy and sharing

No audio is requested. Preview stays on the device. Analysis sends selected frames and recent observed context to the configured inference service. This backend does not persist footage, transcripts, or API keys in logs. Your provider may have separate retention rules. Stop prevents new capture; it cannot recall frames already sent. Text-to-speech uses the browser/OS speech service.

For a WhatsApp link, deploy the **whole application** over HTTPS using [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md). A phone's `localhost` points to the phone, not your laptop. GitHub Pages alone cannot host this Python backend. WhatsApp's embedded browser may restrict camera access; use **Open in browser** in Chrome/Safari if needed.

## Project map

```text
backend/       FastAPI, provider contracts, optional Sanket worker
frontend/      Accessible HTML/CSS/JS, camera lifecycle controller, app manifest
tests/         Backend, camera unit, and shared-browser integration tests
scripts/       Readiness-aware Windows launch helper
legacy/        Preserved signbridge7 source/integration reference, not served
docs/          Model architecture, setup, deployment, and validation details
.env.example   Server-only placeholders; no tokens bundled
Dockerfile     Small web/API deployment (model worker is separate)
render.yaml    Example HTTPS hosting blueprint
```

For validation commands and recorded limitations, see [docs/TESTING.md](docs/TESTING.md). Model files, caches, environments, and secrets are excluded from Git and the download package. Third-party models have their own license terms; see `legacy/LICENSE-NOTICE.md` and `docs/ARCHITECTURE.md`.


## Camera startup fix

The camera controller now retries with progressively simpler video constraints, waits for actual video metadata before reporting success, and displays actionable permission/busy-device errors. Open the app at `http://localhost:8000` (not by double-clicking `index.html`). In Chrome, allow Camera in Site settings. If Windows reports the camera is busy, close the Windows Camera app, Zoom/Teams, and other tabs using it. MediaPipe loads separately; a CDN failure should not prevent the camera preview from opening.


## Applying the sentence-generation worker fix

This update preserves the existing local `.env`, `.sanket-venv`, and `sanket-upstream` assets when extracted **over the same `sbfix` project folder**. Do not extract into a separate folder for an already-installed local worker. `START-SIGNBRIDGE.bat` now detects the installed checkpoint and routes to `START-SIGNBRIDGE-WITH-ISL.bat`, which starts the worker and waits for `/health` before opening the site. The server uses `http://127.0.0.1:8765` as the local worker URL only when `SANKET_URL` is unset; an explicit setting still takes precedence.
